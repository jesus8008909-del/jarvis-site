import { Connector, DemoScenario } from '../types';

export const SOCIAL_AVATARS = [
  {
    name: "Alex Rivera",
    role: "Staff Engineer at Vercel",
    url: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80",
    fallback: "AR"
  },
  {
    name: "Sarah Chen",
    role: "Product Lead at Figma",
    url: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=120&auto=format&fit=crop&q=80",
    fallback: "SC"
  },
  {
    name: "Marcus Brody",
    role: "Founding Designer",
    url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80",
    fallback: "MB"
  },
  {
    name: "Elena Rostova",
    role: "AI Researcher",
    url: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=120&auto=format&fit=crop&q=80",
    fallback: "ER"
  },
  {
    name: "David Kim",
    role: "Software Architect",
    url: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80",
    fallback: "DK"
  }
];

export const DEMO_SCENARIOS: DemoScenario[] = [
  {
    id: 'code',
    title: 'Code & Terminal',
    app: 'VS Code',
    appIcon: 'Code2',
    windowTitle: 'PaymentService.ts — ~/src/services',
    screenContent: {
      type: 'code',
      previewSnippet: `export async function verifyWebhook(signature: string, payload: Buffer) {
  const computedSig = crypto.createHmac('sha256', SECRET).update(payload).digest('hex');
  // Error: Signature verification timing attack vulnerability detected
  return computedSig === signature;
}`
    },
    query: 'How to do timing-safe signature comparison here?',
    response: 'Use `crypto.timingSafeEqual(Buffer.from(computedSig), Buffer.from(signature))`. This prevents timing leaks when comparing HMACs.',
    hotkey: '⌘ Shift J'
  },
  {
    id: 'email',
    title: 'Email & Slack',
    app: 'Slack',
    appIcon: 'MessageSquare',
    windowTitle: '#product-launches · Acme Workspace',
    screenContent: {
      type: 'slack',
      previewSnippet: `Liam: "Hey, can we delay the beta rollout by 2 weeks so marketing has time to prep the keynote?"
You are typing a reply...`
    },
    query: 'Sound collaborative but keep the beta launch date on track',
    response: '"I hear you on marketing prep! Let\'s keep the internal beta rollout for this Friday so we catch bugs early, and align the public announcement with marketing\'s keynote schedule."',
    hotkey: '⌘ Shift J'
  },
  {
    id: 'design',
    title: 'Figma & Specs',
    app: 'Figma',
    appIcon: 'Layers',
    windowTitle: 'Checkout Flow v4 — Mobile Sheet Component',
    screenContent: {
      type: 'figma',
      previewSnippet: `Selected element: [Confirm Order Button]
Background: #10B981 | Text: #FFFFFF
Padding: 14px 28px | Height: 48px`
    },
    query: 'Does this green pass WCAG AAA for normal text?',
    response: '#10B981 on white has a contrast ratio of 2.27:1 (Fails AA & AAA). Switch to #047857 (4.72:1 - Passes AA) or #065F46 (7.1:1 - Passes AAA).',
    hotkey: '⌘ Shift J'
  },
  {
    id: 'doc',
    title: 'Notes & Docs',
    app: 'Notion',
    appIcon: 'Globe',
    windowTitle: 'Q3 Enterprise Architecture Roadmap',
    screenContent: {
      type: 'document',
      previewSnippet: `Current latency SLA: 99.9th percentile at 420ms across 14 regions.
Target for EU expansion: Reduce P95 to under 80ms using edge caching.`
    },
    query: 'What caching header strategy works best for this?',
    response: '`Cache-Control: s-maxage=3600, stale-while-revalidate=86400` combined with Cloudflare/Fastly geo-tier caching will keep edge hits < 40ms.',
    hotkey: '⌘ Shift J'
  }
];

export const CONNECTORS: Connector[] = [
  {
    id: 'vscode',
    name: 'VS Code & Cursor',
    category: 'code',
    description: 'Reads active cursor line, compiler diagnostics, and terminal error stack traces.',
    iconName: 'Code2',
    sampleQuery: 'Why is this Promise unhandled?',
    sampleAnswer: 'Line 42 throws an unhandled rejection because the async catch block was omitted.',
    color: '#007ACC'
  },
  {
    id: 'slack',
    name: 'Slack & Teams',
    category: 'communication',
    description: 'Summarizes long threads, drafts replies in your tone, and checks channel context.',
    iconName: 'MessageSquare',
    sampleQuery: 'What was decided in the #mobile-redesign thread?',
    sampleAnswer: 'Team chose option B (bottom sheet) to ship next Tuesday.',
    color: '#4A154B'
  },
  {
    id: 'figma',
    name: 'Figma & Penpot',
    category: 'design',
    description: 'Calculates contrast ratios, converts styles to Tailwind/CSS tokens instantly.',
    iconName: 'Layers',
    sampleQuery: 'Convert selected drop-shadow to Tailwind class',
    sampleAnswer: 'shadow-[0_12px_24px_-6px_rgba(0,0,0,0.12)]',
    color: '#F24E1E'
  },
  {
    id: 'notion',
    name: 'Notion & Obsidian',
    category: 'productivity',
    description: 'Surfaces relevant notes, references previous meeting minutes without switching tabs.',
    iconName: 'Globe',
    sampleQuery: 'Where is our refund policy document?',
    sampleAnswer: 'Saved in "Ops Handbook > Customer Success > Tier 1 Refunds (Updated Aug 14)".',
    color: '#000000'
  },
  {
    id: 'linear',
    name: 'Linear & Jira',
    category: 'productivity',
    description: 'Creates concise bug reports from screen context, updates issue status via keyboard.',
    iconName: 'Zap',
    sampleQuery: 'Draft a Linear ticket for this crash log',
    sampleAnswer: 'Title: [Auth] Token expiry crash on iOS Safari 17.4',
    color: '#5E6AD2'
  },
  {
    id: 'chrome',
    name: 'Chrome & Safari',
    category: 'productivity',
    description: 'Reads open documentation, explains difficult passages, extracts key metrics from tables.',
    iconName: 'Monitor',
    sampleQuery: 'Summarize the breaking changes in Next.js 15',
    sampleAnswer: 'Async request headers/cookies, React 19 support, and fetch caching defaults changed to uncached.',
    color: '#EA4335'
  }
];

export const COMPARISONS = [
  {
    feature: "Screen-aware context",
    jarvis: "Sees whatever you're looking at without screenshotting or pasting",
    webChat: "Requires manual copy-pasting, screenshots, or lengthy prompts",
  },
  {
    feature: "Zero flow disruption",
    jarvis: "Instant HUD overlay via ⌘ Space; auto-dismisses when you continue",
    webChat: "Forces tab switching, breaking focus and window placement",
  },
  {
    feature: "Local privacy controls",
    jarvis: "Hardware-accelerated local parsing with app blacklist toggle",
    webChat: "Full browser session history sent without fine-grained scoping",
  },
  {
    feature: "Native App Connectors",
    jarvis: "Directly bridges with VS Code, Figma, Slack, Notion, and Terminal",
    webChat: "Isolated in browser sandbox with zero desktop app hooks",
  }
];
