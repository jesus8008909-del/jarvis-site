export type OS = 'macos' | 'windows' | 'linux';

export interface Connector {
  id: string;
  name: string;
  category: 'code' | 'design' | 'productivity' | 'communication';
  description: string;
  iconName: string;
  sampleQuery: string;
  sampleAnswer: string;
  color: string;
}

export interface DemoScenario {
  id: string;
  title: string;
  app: string;
  appIcon: string;
  windowTitle: string;
  screenContent: {
    type: 'code' | 'document' | 'slack' | 'figma';
    previewSnippet: string;
  };
  query: string;
  response: string;
  hotkey: string;
}
