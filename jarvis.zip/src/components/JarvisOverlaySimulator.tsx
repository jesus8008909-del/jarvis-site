import React, { useState, useEffect } from 'react';
import { JarvisLogo } from './JarvisLogo';
import { Sparkles, X, Send, CornerDownLeft, Command, Check } from 'lucide-react';

interface JarvisOverlaySimulatorProps {
  isOpen: boolean;
  onClose: () => void;
  initialQuery?: string;
}

const PRESET_QUESTIONS = [
  "What is the shortcut to split screen on Windows?",
  "Convert 16px to rem with base 16",
  "How to undo last git commit without losing files?",
  "Polish this sentence: 'I am checking to see if you got my email'"
];

export function JarvisOverlaySimulator({ isOpen, onClose, initialQuery = '' }: JarvisOverlaySimulatorProps) {
  const [query, setQuery] = useState(initialQuery);
  const [answer, setAnswer] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (initialQuery) {
      setQuery(initialQuery);
      handleAsk(initialQuery);
    }
  }, [initialQuery]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Toggle on Cmd+Shift+J or Alt+Space or Escape to close
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
      if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key.toLowerCase() === 'j') {
        e.preventDefault();
        if (isOpen) {
          onClose();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleAsk = (userQuery?: string) => {
    const q = userQuery || query.trim();
    if (!q) return;

    setIsLoading(true);
    setAnswer(null);

    setTimeout(() => {
      let simulatedResponse = `Direct answer: For "${q}", Jarvis synthesizes your on-screen active context instantly with zero window switching.`;

      if (q.toLowerCase().includes('windows') && q.toLowerCase().includes('split')) {
        simulatedResponse = "Press Windows Key + Left/Right Arrow to snap windows. Windows Key + Up snaps to top-half or maximizes.";
      } else if (q.toLowerCase().includes('rem') || q.toLowerCase().includes('16px')) {
        simulatedResponse = "16px = 1rem (Calculation: 16 ÷ 16 = 1rem). 12px is 0.75rem, and 24px is 1.5rem.";
      } else if (q.toLowerCase().includes('git commit') || q.toLowerCase().includes('undo')) {
        simulatedResponse = "Run `git reset --soft HEAD~1`. This keeps your staged changes intact and unwinds only the commit.";
      } else if (q.toLowerCase().includes('polish') || q.toLowerCase().includes('email')) {
        simulatedResponse = 'Polished: "Following up on my previous note — let me know if you need any additional details from my end."';
      }

      setAnswer(simulatedResponse);
      setIsLoading(false);
    }, 400);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 max-w-md w-[calc(100vw-3rem)] animate-in slide-in-from-bottom-5 duration-200">
      <div className="bg-neutral-900/95 backdrop-blur-xl border border-neutral-700 rounded-2xl shadow-2xl p-4 text-neutral-100 font-sans">
        {/* Top bar */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <div className="p-1 rounded-md bg-white text-neutral-950">
              <JarvisLogo className="w-4 h-4" />
            </div>
            <span className="font-semibold text-xs tracking-tight">Jarvis Ambient HUD</span>
            <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-mono">
              ON-SCREEN
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] text-neutral-400 font-mono hidden sm:inline">ESC to dismiss</span>
            <button
              type="button"
              onClick={onClose}
              className="text-neutral-400 hover:text-white p-1 rounded hover:bg-neutral-800 transition-colors"
              aria-label="Close Jarvis overlay"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Input */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleAsk();
          }}
          className="mt-3 relative"
        >
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ask a small question..."
            autoFocus
            className="w-full bg-neutral-950 border border-neutral-700/80 rounded-xl pl-3.5 pr-10 py-2.5 text-xs text-neutral-100 placeholder:text-neutral-500 focus:outline-hidden focus:border-amber-400/80"
          />
          <button
            type="submit"
            disabled={!query.trim() || isLoading}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-lg bg-neutral-100 text-neutral-950 hover:bg-white disabled:opacity-30 disabled:hover:bg-neutral-100 transition-all cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>

        {/* Presets if no answer yet */}
        {!answer && !isLoading && (
          <div className="mt-3">
            <p className="text-[10px] uppercase font-semibold text-neutral-500 tracking-wider mb-1.5">
              Try a quick micro-question:
            </p>
            <div className="flex flex-col gap-1">
              {PRESET_QUESTIONS.map((pq, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => {
                    setQuery(pq);
                    handleAsk(pq);
                  }}
                  className="text-left text-xs text-neutral-300 hover:text-white py-1 px-2 rounded-lg hover:bg-neutral-800/70 transition-colors truncate"
                >
                  › {pq}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Loading */}
        {isLoading && (
          <div className="mt-3 p-3 bg-neutral-950/60 rounded-xl border border-neutral-800 flex items-center gap-2 text-xs text-neutral-400">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
            <span>Parsing active context...</span>
          </div>
        )}

        {/* Answer */}
        {answer && !isLoading && (
          <div className="mt-3 p-3 bg-neutral-950/80 rounded-xl border border-neutral-800 text-xs leading-relaxed text-neutral-200">
            <p>{answer}</p>
            <div className="mt-2 pt-2 border-t border-neutral-800/80 flex items-center justify-between text-[11px] text-neutral-400">
              <span>Ready to copy into your app</span>
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(answer);
                  onClose();
                }}
                className="text-amber-400 hover:text-amber-300 font-medium"
              >
                Copy & Close
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
