import React, { useState, useEffect, useRef } from 'react';
import { AppleIcon, WindowsIcon } from './JarvisIcons';
import { Menu, X } from 'lucide-react';
import { OS } from '../types';

interface NavbarProps {
  onOpenDownload: (os?: OS) => void;
  onOpenPricing: () => void;
  onNavigateSection: (sectionId: string) => void;
}

export function Navbar({ onOpenDownload, onOpenPricing, onNavigateSection }: NavbarProps) {
  const [isScrolledPastHero, setIsScrolledPastHero] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [detectedOS, setDetectedOS] = useState<'mac' | 'windows'>('windows');
  const navRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (typeof navigator !== 'undefined') {
      const isMac = /Mac|iPhone|iPod|iPad/i.test(navigator.platform || navigator.userAgent);
      setDetectedOS(isMac ? 'mac' : 'windows');
    }

    const checkScroll = () => {
      const hero = document.getElementById('hero');
      if (!hero) {
        setIsScrolledPastHero(window.scrollY > 80);
        return;
      }
      const navHeight = navRef.current?.offsetHeight ?? 64;
      const heroBottom = hero.getBoundingClientRect().bottom;
      setIsScrolledPastHero(heroBottom <= 16 + navHeight);
    };

    checkScroll();
    window.addEventListener('scroll', checkScroll, { passive: true });
    window.addEventListener('resize', checkScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', checkScroll);
      window.removeEventListener('resize', checkScroll);
    };
  }, []);

  const navLinks = [
    { id: 'connectors', label: 'Connectors' },
    { id: 'integrations', label: 'Integrations' },
    { id: 'use-cases', label: 'Use Cases' },
    { id: 'compare', label: 'Compare' },
    { id: 'alternatives', label: 'Alternatives' },
    { id: 'blog', label: 'Blog' },
    { id: 'pricing', label: 'Pricing' },
  ];

  const handleLinkClick = (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    if (id === 'pricing') {
      onOpenPricing();
    } else {
      onNavigateSection(id);
    }
  };

  const isHero = !isScrolledPastHero;

  // Liquid glass box-shadow layers matching getjarvis.eu
  const liquidGlassShadow = [
    'inset 2px 2px 0 -1px rgba(255,255,255,1)',
    'inset -2px -2px 0 -1px rgba(255,255,255,0.60)',
    'inset 0 0 14px -2px rgba(255,255,255,0.45)',
    'inset 0 0 0 1px rgba(255,255,255,0.26)',
    '0 0 0 1px rgba(39,35,29,0.06)',
    '0 16px 38px -12px rgba(20,16,10,0.30)'
  ].join(', ');

  const ctaShadow = '0 1px 3px rgba(0,0,0,0.08), 0 4px 12px rgba(0,0,0,0.04)';

  return (
    <nav
      ref={navRef}
      id="main-navigation"
      className="jarvis-navbar-root"
      style={{
        position: 'fixed',
        top: 16,
        left: '50%',
        transform: 'translateX(-50%)',
        zIndex: 50,
        width: 'auto',
        maxWidth: 'calc(100% - 32px)',
      }}
    >
      <style>{`
        .jarvis-navbar-desktop {
          --jarvis-nav-logo-height: clamp(20px, 2.35vw, 30px);
          --jarvis-nav-logo-margin: clamp(7px, 1.3vw, 20px);
          --jarvis-nav-link-font: clamp(11.5px, 1.2vw, 14.5px);
          --jarvis-nav-link-pad-y: clamp(5px, 0.65vw, 8px);
          --jarvis-nav-link-pad-x: clamp(6px, 0.85vw, 12px);
          --jarvis-nav-pill-pad-left: clamp(12px, 2vw, 26px);
          --jarvis-nav-pill-pad-right: clamp(8px, 0.95vw, 12px);
          --jarvis-nav-pill-pad-y: clamp(7px, 0.9vw, 10px);
          --jarvis-nav-cta-margin: clamp(7px, 1.25vw, 20px);
          --jarvis-nav-cta-margin-hero: clamp(20px, 3.6vw, 48px);
          --jarvis-nav-logo-margin-hero: clamp(20px, 3.6vw, 48px);
          --jarvis-nav-cta-height: clamp(32px, 3.3vw, 38px);
          --jarvis-nav-cta-padding: clamp(6px, 0.85vw, 9px) clamp(10px, 1.1vw, 16px);
          --jarvis-nav-cta-font-size: clamp(11.5px, 1.1vw, 14px);
          --jarvis-nav-cta-line-height: 1;
          --jarvis-nav-cta-gap: clamp(5px, 0.7vw, 8px);
          align-items: center;
          box-sizing: border-box;
          display: flex;
          max-width: calc(100vw - 32px);
          padding:
            var(--jarvis-nav-pill-pad-y)
            var(--jarvis-nav-pill-pad-right)
            var(--jarvis-nav-pill-pad-y)
            var(--jarvis-nav-pill-pad-left);
          width: max-content;
          border-radius: 9999px;
          background-color: rgba(255, 255, 255, 0.42);
        }

        .jarvis-navbar-desktop--hero .jarvis-navbar-logo {
          margin-right: var(--jarvis-nav-logo-margin-hero);
        }
        .jarvis-navbar-desktop--hero .jarvis-navbar-cta {
          margin-left: var(--jarvis-nav-cta-margin-hero);
        }

        .jarvis-navbar-logo {
          flex-shrink: 0;
          margin-right: var(--jarvis-nav-logo-margin);
          transition: margin-right 420ms cubic-bezier(0.22, 1, 0.36, 1);
        }
        .jarvis-navbar-logo img {
          display: block;
          height: var(--jarvis-nav-logo-height);
          width: auto;
        }

        .jarvis-navbar-links {
          align-items: center;
          display: flex;
          flex-shrink: 0;
          gap: 2px;
        }

        .jarvis-glass {
          position: relative;
          isolation: isolate;
          transition: background-color 420ms ease, box-shadow 420ms ease;
        }
        .jarvis-glass > .glass-base,
        .jarvis-glass > .glass-rim {
          position: absolute;
          inset: 0;
          border-radius: inherit;
          pointer-events: none;
        }
        .jarvis-glass > .glass-base {
          z-index: -2;
          -webkit-backdrop-filter: blur(14px) saturate(170%);
          backdrop-filter: blur(14px) saturate(170%);
        }
        .jarvis-glass > .glass-rim {
          z-index: -1;
          -webkit-backdrop-filter: blur(30px) saturate(230%) brightness(1.15);
          backdrop-filter: blur(30px) saturate(230%) brightness(1.15);
          -webkit-mask-image: radial-gradient(115% 190% at 50% 50%, transparent 34%, #000 78%);
          mask-image: radial-gradient(115% 190% at 50% 50%, transparent 34%, #000 78%);
        }

        .jarvis-navbar-link {
          border-radius: 9999px;
          display: block;
          font-size: var(--jarvis-nav-link-font);
          font-weight: 500;
          letter-spacing: -0.01em;
          padding: var(--jarvis-nav-link-pad-y) var(--jarvis-nav-link-pad-x);
          text-decoration: none;
          transition: all 0.2s ease;
          white-space: nowrap;
          color: rgba(39, 35, 29, 0.72);
          background: transparent;
        }
        .jarvis-navbar-link:hover {
          color: rgba(39, 35, 29, 0.98);
          background: rgba(39, 35, 29, 0.05);
        }

        .jarvis-navbar-cta {
          flex-shrink: 0;
          margin-left: var(--jarvis-nav-cta-margin);
          transition: margin-left 420ms cubic-bezier(0.22, 1, 0.36, 1);
        }

        @media (max-width: 900px) {
          .jarvis-navbar-links {
            display: none !important;
          }
          .jarvis-navbar-desktop--hero .jarvis-navbar-logo {
            margin-right: 14px;
          }
          .jarvis-navbar-desktop--hero .jarvis-navbar-cta {
            margin-left: 14px;
          }
        }
      `}</style>

      {/* Main Glass Pill */}
      <div
        className={`jarvis-glass jarvis-navbar-desktop ${isHero ? 'jarvis-navbar-desktop--hero' : ''}`}
        style={{
          boxShadow: liquidGlassShadow,
        }}
      >
        <div className="glass-base" />
        <div className="glass-rim" />

        {/* Logo */}
        <a
          href="#top"
          onClick={(e) => handleLinkClick(e, 'top')}
          className="jarvis-navbar-logo select-none"
          aria-label="Jarvis Home"
          id="nav-brand-link"
        >
          <img
            src="/sidebar-logo-ink.png"
            alt="Jarvis"
            width="133"
            height="36"
            onError={(e) => {
              // Fallback to text if image fails
              const target = e.currentTarget;
              target.style.display = 'none';
              if (target.parentElement) {
                target.parentElement.innerHTML = '<span style="font-weight:700;font-size:22px;letter-spacing:-0.03em;color:#27231D;">Jarvis</span>';
              }
            }}
          />
        </a>

        {/* Links */}
        <div className="jarvis-navbar-links">
          {navLinks.map((link) => (
            <a
              key={link.id}
              href={`#${link.id}`}
              onClick={(e) => handleLinkClick(e, link.id)}
              className="jarvis-navbar-link"
              id={`nav-link-${link.id}`}
            >
              {link.label}
            </a>
          ))}
        </div>

        {/* CTA Button */}
        <div className="jarvis-navbar-cta flex items-center gap-2">
          <button
            type="button"
            onClick={() => onOpenDownload(detectedOS === 'mac' ? 'macos' : 'windows')}
            className="inline-flex items-center cursor-pointer transition-all duration-150 hover:brightness-105 active:scale-[0.98]"
            style={{
              height: 'var(--jarvis-nav-cta-height)',
              padding: 'var(--jarvis-nav-cta-padding)',
              fontSize: 'var(--jarvis-nav-cta-font-size)',
              gap: 'var(--jarvis-nav-cta-gap)',
              borderRadius: 9999,
              backgroundColor: '#1E1B18',
              color: '#FAF6F0',
              fontWeight: 500,
              boxShadow: ctaShadow,
              border: '1px solid rgba(255,255,255,0.12)',
            }}
            id="nav-download-cta"
          >
            {detectedOS === 'mac' ? (
              <AppleIcon className="w-3.5 h-3.5 text-white/90" />
            ) : (
              <WindowsIcon className="w-3.5 h-3.5 text-white/90" />
            )}
            <span className="font-medium whitespace-nowrap">
              {detectedOS === 'mac' ? 'Get for Mac' : 'Get for Windows'}
            </span>
          </button>

          {/* Mobile Menu Toggle button on tablet/mobile */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-1.5 rounded-full text-neutral-800 hover:bg-black/5 transition-colors cursor-pointer"
            aria-label="Toggle navigation menu"
            id="mobile-nav-toggle-btn"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div
          className="mt-3 p-4 rounded-2xl bg-white/95 backdrop-blur-xl border border-neutral-200/80 shadow-2xl flex flex-col gap-1 lg:hidden"
          style={{ width: 'calc(100vw - 32px)', maxWidth: 440 }}
          id="mobile-nav-drawer"
        >
          {navLinks.map((link) => (
            <a
              key={link.id}
              href={`#${link.id}`}
              onClick={(e) => handleLinkClick(e, link.id)}
              className="py-2.5 px-3.5 rounded-xl text-neutral-800 font-medium hover:bg-neutral-100 transition-colors text-sm"
            >
              {link.label}
            </a>
          ))}
          <div className="pt-3 mt-1 border-t border-neutral-100 flex flex-col gap-2">
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenDownload('windows');
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-neutral-900 text-white font-medium text-sm hover:bg-neutral-800"
            >
              <WindowsIcon className="w-4 h-4" />
              <span>Download for Windows</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenDownload('macos');
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-neutral-100 text-neutral-800 font-medium text-sm hover:bg-neutral-200"
            >
              <AppleIcon className="w-4 h-4" />
              <span>Download for macOS</span>
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
