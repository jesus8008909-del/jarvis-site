import React from 'react';
import { COMPARISONS } from '../data/mockData';
import { Check, X, Sparkles, Monitor, AppWindow, Zap, Shield, Eye } from 'lucide-react';

export function ComparisonSection() {
  return (
    <section id="compare" className="py-16 sm:py-24 px-4 sm:px-6 max-w-6xl mx-auto border-t border-neutral-200/80">
      <div className="text-center mb-12 sm:mb-16">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider text-neutral-600 bg-neutral-200/80 mb-3">
          <span>Compare & Alternatives</span>
        </div>
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-neutral-900 tracking-tight">
          Why an ambient assistant beats browser tabs
        </h2>
        <p className="mt-3 text-lg text-neutral-600 max-w-2xl mx-auto">
          You shouldn't have to break your train of thought, switch virtual desktops, or copy-paste confidential code just to get a question answered.
        </p>
      </div>

      {/* Comparison Grid Table */}
      <div className="bg-white border border-neutral-200/90 rounded-2xl shadow-xs overflow-hidden">
        <div className="grid grid-cols-12 bg-neutral-100/70 border-b border-neutral-200/90 p-4 sm:p-5 font-semibold text-xs sm:text-sm text-neutral-700">
          <div className="col-span-5 sm:col-span-4">Experience Metric</div>
          <div className="col-span-7 sm:col-span-4 flex items-center gap-2 text-neutral-900">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            Jarvis (Ambient Screen AI)
          </div>
          <div className="hidden sm:block sm:col-span-4 text-neutral-500">
            Traditional Web AI Tabs
          </div>
        </div>

        <div className="divide-y divide-neutral-100">
          {COMPARISONS.map((item, idx) => (
            <div key={idx} className="grid grid-cols-12 p-4 sm:p-5 text-xs sm:text-sm hover:bg-neutral-50/50 transition-colors">
              <div className="col-span-5 sm:col-span-4 font-semibold text-neutral-900 pr-2 flex items-center gap-2">
                <span>{item.feature}</span>
              </div>
              <div className="col-span-7 sm:col-span-4 text-neutral-800 pr-3 flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>{item.jarvis}</span>
              </div>
              <div className="hidden sm:flex sm:col-span-4 text-neutral-500 items-start gap-2">
                <X className="w-4 h-4 text-neutral-400 shrink-0 mt-0.5" />
                <span>{item.webChat}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3 Core Value Props */}
      <div id="use-cases" className="mt-14 sm:mt-20 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white border border-neutral-200/80 rounded-2xl p-6 sm:p-7 shadow-xs">
          <div className="w-10 h-10 rounded-xl bg-neutral-100 flex items-center justify-center text-neutral-900 mb-4">
            <Zap className="w-5 h-5 text-neutral-900" />
          </div>
          <h3 className="text-lg font-bold text-neutral-900 mb-2">Micro-moments of flow</h3>
          <p className="text-sm text-neutral-600 leading-relaxed">
            The best questions are 5 seconds long: "What was that regex again?", "Does this hex contrast pass?", "What's the syntax for this CLI flag?". Jarvis answers in place so you never lose momentum.
          </p>
        </div>

        <div className="bg-white border border-neutral-200/80 rounded-2xl p-6 sm:p-7 shadow-xs">
          <div className="w-10 h-10 rounded-xl bg-neutral-100 flex items-center justify-center text-neutral-900 mb-4">
            <Eye className="w-5 h-5 text-neutral-900" />
          </div>
          <h3 className="text-lg font-bold text-neutral-900 mb-2">Sees what you see</h3>
          <p className="text-sm text-neutral-600 leading-relaxed">
            Jarvis reads your active window's optical and semantic layer. When you ask "Why is this failing?", it already knows the line number, error code, and relevant imports.
          </p>
        </div>

        <div className="bg-white border border-neutral-200/80 rounded-2xl p-6 sm:p-7 shadow-xs">
          <div className="w-10 h-10 rounded-xl bg-neutral-100 flex items-center justify-center text-neutral-900 mb-4">
            <Shield className="w-5 h-5 text-neutral-900" />
          </div>
          <h3 className="text-lg font-bold text-neutral-900 mb-2">Zero-telemetry privacy</h3>
          <p className="text-sm text-neutral-600 leading-relaxed">
            Your screen buffer stays encrypted in RAM. You choose which apps are visible to Jarvis, and bank credentials or password fields are masked automatically.
          </p>
        </div>
      </div>
    </section>
  );
}
