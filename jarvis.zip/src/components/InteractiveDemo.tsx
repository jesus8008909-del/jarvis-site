import React, { useState } from 'react';
import { DEMO_SCENARIOS } from '../data/mockData';
import { JarvisLogo } from './JarvisLogo';
import { Code2, MessageSquare, Layers, Globe, Sparkles, Send, Check, Copy, CornerDownLeft, RotateCcw } from 'lucide-react';

interface InteractiveDemoProps {
  onTriggerFloatingOverlay: (initialQuery?: string) => void;
}

export function InteractiveDemo({ onTriggerFloatingOverlay }: InteractiveDemoProps) {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>('code');
  const [customInput, setCustomInput] = useState<string>('');
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [copied, setCopied] = useState(false);
  const [isThinking, setIsThinking] = useState(false);

  const currentScenario = DEMO_SCENARIOS.find(s => s.id === selectedScenarioId) || DEMO_SCENARIOS[0];

  const handleRunQuery = (scenarioQuery?: string) => {
    const queryToRun = scenarioQuery || customInput.trim();
    if (!queryToRun) return;

    setIsThinking(true);
    setTimeout(() => {
      let result = currentScenario.response;
      if (customInput.trim()) {
        result = `Based on your active ${currentScenario.app} window: "${customInput.trim()}" — Jarvis answers immediately within your current context without switching tabs.`;
      }
      setAnswers(prev => ({
        ...prev,
        [currentScenario.id]: result
      }));
      setIsThinking(false);
      setCustomInput('');
    }, 450);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const currentAnswer = answers[currentScenario.id] || currentScenario.response;

  return (
    <section id="demo" className="py-12 sm:py-16 px-4 sm:px-6 max-w-6xl mx-auto">
      <div className="text-center mb-8 sm:mb-10">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider text-neutral-600 bg-neutral-200/80 mb-3">
          <span>Live Workspace Simulator</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-bold text-neutral-900 tracking-tight">
          Always there when you need an answer
        </h2>
        <p className="mt-2 text-neutral-600 max-w-xl mx-auto text-base">
          No copy-pasting code into a chat window. Jarvis reads your active workspace context with a single keystroke.
        </p>
      </div>

      {/* Scenario Tabs */}
      <div className="flex items-center justify-center gap-2 sm:gap-3 flex-wrap mb-6">
        {DEMO_SCENARIOS.map((scenario) => {
          const isActive = scenario.id === selectedScenarioId;
          const Icon = scenario.id === 'code' ? Code2 : scenario.id === 'email' ? MessageSquare : scenario.id === 'design' ? Layers : Globe;
          return (
            <button
              key={scenario.id}
              type="button"
              onClick={() => setSelectedScenarioId(scenario.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all cursor-pointer ${
                isActive
                  ? 'bg-neutral-900 text-white shadow-sm'
                  : 'bg-white text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900 border border-neutral-200/80'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{scenario.title}</span>
            </button>
          );
        })}
      </div>

      {/* Interactive Mock Desktop Window */}
      <div className="relative rounded-2xl bg-neutral-900 shadow-2xl border border-neutral-800 overflow-hidden">
        {/* Window Chrome Title Bar */}
        <div className="bg-neutral-950/80 px-4 py-3 border-b border-neutral-800/80 flex items-center justify-between select-none">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-red-500/80 inline-block" />
            <span className="w-3 h-3 rounded-full bg-yellow-500/80 inline-block" />
            <span className="w-3 h-3 rounded-full bg-green-500/80 inline-block" />
            <span className="ml-3 text-xs font-mono text-neutral-400 truncate max-w-[200px] sm:max-w-md">
              {currentScenario.windowTitle}
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <span className="hidden sm:inline">Hotkey:</span>
            <kbd className="px-2 py-0.5 rounded bg-neutral-800 border border-neutral-700 font-mono text-neutral-300 text-[11px]">
              {currentScenario.hotkey}
            </kbd>
          </div>
        </div>

        {/* Screen Background App Mockup */}
        <div className="p-5 sm:p-7 min-h-[360px] sm:min-h-[400px] bg-neutral-950 relative font-mono text-xs sm:text-sm text-neutral-300 flex flex-col justify-between">
          {/* Active app content preview */}
          <div className="opacity-70 select-text overflow-x-auto whitespace-pre-wrap leading-relaxed pb-28">
            <div className="text-neutral-500 mb-2 font-sans font-medium text-xs flex items-center gap-2">
              <span className="inline-block w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
              Active App Context: {currentScenario.app}
            </div>
            <code>{currentScenario.screenContent.previewSnippet}</code>
          </div>

          {/* Floating Jarvis Overlay Card (Simulating native desktop HUD) */}
          <div className="absolute inset-x-4 sm:inset-x-8 bottom-5 max-w-2xl mx-auto">
            <div className="bg-neutral-900/95 backdrop-blur-xl border border-neutral-700/80 rounded-2xl shadow-2xl p-4 sm:p-5 transition-all text-neutral-100 font-sans">
              {/* Jarvis HUD Header */}
              <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
                <div className="flex items-center gap-2">
                  <div className="p-1 rounded-md bg-white text-neutral-950">
                    <JarvisLogo className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-semibold text-neutral-200">Jarvis</span>
                  <span className="text-[11px] text-neutral-400 bg-neutral-800 px-2 py-0.5 rounded-full">
                    Context: {currentScenario.app}
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => onTriggerFloatingOverlay(currentScenario.query)}
                    className="text-[11px] text-amber-400 hover:text-amber-300 font-medium px-2 py-0.5 rounded hover:bg-neutral-800 transition-colors flex items-center gap-1"
                    title="Open as interactive screen overlay"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>Open HUD</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleCopy(currentAnswer)}
                    className="text-neutral-400 hover:text-neutral-200 p-1 rounded hover:bg-neutral-800 transition-colors"
                    title="Copy Answer"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Sample Query / Question */}
              <div className="mt-3 flex items-start gap-2">
                <div className="w-5 h-5 rounded-full bg-neutral-800 flex items-center justify-center shrink-0 mt-0.5 text-neutral-400 text-xs">
                  Q
                </div>
                <p className="text-sm font-medium text-neutral-200">
                  {currentScenario.query}
                </p>
              </div>

              {/* Response Stream / Answer */}
              <div className="mt-2 pl-7">
                {isThinking ? (
                  <div className="flex items-center gap-2 text-xs text-neutral-400 py-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping"></span>
                    <span>Reading {currentScenario.app} buffer & synthesizing...</span>
                  </div>
                ) : (
                  <p className="text-xs sm:text-[13px] text-neutral-300 leading-relaxed bg-neutral-950/60 p-2.5 rounded-xl border border-neutral-800/80">
                    {currentAnswer}
                  </p>
                )}
              </div>

              {/* Interactive prompt input bar */}
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleRunQuery();
                }}
                className="mt-3 flex items-center gap-2 pt-2 border-t border-neutral-800"
              >
                <input
                  type="text"
                  value={customInput}
                  onChange={(e) => setCustomInput(e.target.value)}
                  placeholder={`Ask anything about this ${currentScenario.app} window...`}
                  className="flex-1 bg-neutral-950/80 border border-neutral-800 rounded-xl px-3 py-1.5 text-xs text-neutral-200 placeholder:text-neutral-500 focus:outline-hidden focus:border-neutral-600 transition-colors"
                />
                <button
                  type="submit"
                  disabled={!customInput.trim()}
                  className="p-2 rounded-xl bg-neutral-100 text-neutral-950 hover:bg-white disabled:opacity-30 disabled:hover:bg-neutral-100 transition-all cursor-pointer"
                  title="Submit Query"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
