import React, { useState } from 'react';
import { X, Check, Sparkles } from 'lucide-react';
import { JarvisLogo } from './JarvisLogo';

interface PricingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPlan: (plan: string) => void;
}

export function PricingModal({ isOpen, onClose, onSelectPlan }: PricingModalProps) {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('yearly');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        className="bg-white rounded-2xl max-w-3xl w-full border border-neutral-200 shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto animate-in zoom-in-95 duration-150"
        role="dialog"
        aria-modal="true"
      >
        <div className="px-6 py-5 border-b border-neutral-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <JarvisLogo className="w-6 h-6 text-neutral-900" />
            <h3 className="font-bold text-neutral-900 text-lg">Simple, transparent pricing</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-800 hover:bg-neutral-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 sm:p-8">
          {/* Billing Switch */}
          <div className="flex items-center justify-center gap-3 mb-8">
            <span className={`text-xs font-semibold ${billingCycle === 'monthly' ? 'text-neutral-900' : 'text-neutral-500'}`}>Monthly</span>
            <button
              type="button"
              onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'yearly' : 'monthly')}
              className="relative w-12 h-6 bg-neutral-200 rounded-full p-0.5 transition-colors cursor-pointer"
            >
              <div 
                className={`w-5 h-5 bg-neutral-900 rounded-full shadow-xs transition-transform ${billingCycle === 'yearly' ? 'translate-x-6' : 'translate-x-0'}`}
              />
            </button>
            <span className={`text-xs font-semibold flex items-center gap-1 ${billingCycle === 'yearly' ? 'text-neutral-900' : 'text-neutral-500'}`}>
              <span>Yearly</span>
              <span className="bg-amber-100 text-amber-800 text-[10px] px-1.5 py-0.5 rounded-full font-bold">Save 20%</span>
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Free Starter */}
            <div className="border border-neutral-200 rounded-2xl p-5 flex flex-col justify-between hover:border-neutral-300 transition-all bg-white">
              <div>
                <span className="text-[11px] font-semibold uppercase tracking-wider text-neutral-500">Forever Free</span>
                <h4 className="text-xl font-bold text-neutral-900 mt-1">Starter</h4>
                <p className="text-xs text-neutral-600 mt-1">7-day full Pro trial included, then 40 free requests every week.</p>
                <div className="my-5">
                  <span className="text-3xl font-extrabold text-neutral-900">$0</span>
                  <span className="text-neutral-500 text-xs ml-1">/ forever</span>
                </div>
                <ul className="space-y-2.5 text-xs text-neutral-700">
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-neutral-900 shrink-0" />
                    <span>40 free requests every week</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-neutral-900 shrink-0" />
                    <span>Single hotkey screen overlay</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-neutral-900 shrink-0" />
                    <span>Core app connectors</span>
                  </li>
                </ul>
              </div>
              <button
                type="button"
                onClick={() => onSelectPlan('Starter')}
                className="mt-6 w-full py-2.5 rounded-xl border border-neutral-300 text-neutral-800 font-semibold text-xs hover:bg-neutral-100 transition-colors cursor-pointer"
              >
                Download Free
              </button>
            </div>

            {/* Pro */}
            <div className="border-2 border-neutral-900 rounded-2xl p-5 flex flex-col justify-between relative shadow-md bg-white">
              <div className="absolute -top-3 right-5 bg-neutral-900 text-white text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-400" />
                Popular
              </div>
              <div>
                <span className="text-[11px] font-semibold uppercase tracking-wider text-amber-600">Knowledge Workers</span>
                <h4 className="text-xl font-bold text-neutral-900 mt-1">Jarvis Pro</h4>
                <p className="text-xs text-neutral-600 mt-1">Full access to advanced models and multi-app tasks.</p>
                <div className="my-5">
                  <span className="text-3xl font-extrabold text-neutral-900">
                    ${billingCycle === 'yearly' ? '12' : '16'}
                  </span>
                  <span className="text-neutral-500 text-xs ml-1">/ month</span>
                </div>
                <ul className="space-y-2.5 text-xs text-neutral-700">
                  <li className="flex items-center gap-2 font-medium text-neutral-900">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Fast screen awareness</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>All 30+ native app connectors</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Real-time voice & dictation</span>
                  </li>
                </ul>
              </div>
              <button
                type="button"
                onClick={() => onSelectPlan('Pro')}
                className="mt-6 w-full py-2.5 rounded-xl bg-neutral-900 text-white font-semibold text-xs hover:bg-neutral-800 transition-colors cursor-pointer shadow-xs"
              >
                Get Pro
              </button>
            </div>

            {/* Unlimited */}
            <div className="border border-neutral-200 rounded-2xl p-5 flex flex-col justify-between hover:border-neutral-300 transition-all bg-white">
              <div>
                <span className="text-[11px] font-semibold uppercase tracking-wider text-neutral-500">Power Users</span>
                <h4 className="text-xl font-bold text-neutral-900 mt-1">Unlimited</h4>
                <p className="text-xs text-neutral-600 mt-1">No limits on requests, computer use actions, or reasoning models.</p>
                <div className="my-5">
                  <span className="text-3xl font-extrabold text-neutral-900">
                    ${billingCycle === 'yearly' ? '26' : '32'}
                  </span>
                  <span className="text-neutral-500 text-xs ml-1">/ month</span>
                </div>
                <ul className="space-y-2.5 text-xs text-neutral-700">
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-neutral-900 shrink-0" />
                    <span>Unlimited questions & hotkeys</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-neutral-900 shrink-0" />
                    <span>Autonomous computer use agent</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-neutral-900 shrink-0" />
                    <span>Priority GPU compute pipeline</span>
                  </li>
                </ul>
              </div>
              <button
                type="button"
                onClick={() => onSelectPlan('Unlimited')}
                className="mt-6 w-full py-2.5 rounded-xl border border-neutral-300 text-neutral-800 font-semibold text-xs hover:bg-neutral-100 transition-colors cursor-pointer"
              >
                Get Unlimited
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
