import React, { useState, useEffect } from 'react';
import { ExternalArrowIcon } from './JarvisIcons';
import { OS } from '../types';

interface BentoPairProps {
  onNavigateConnectors?: () => void;
  onOpenDownload?: (os?: OS) => void;
}

const VOICE_DIALOGUE = [
  { role: 'user', text: 'Hey Jarvis, please check my Gmail for anything urgent.' },
  { role: 'jarvis', text: 'How far back should I look — today or the whole week?' },
  { role: 'user', text: "Today's fine, I caught up on everything yesterday." },
  { role: 'jarvis', text: 'On it — scanning your inbox for anything that needs you.' },
  { role: 'user', text: "I'm especially interested in updates from my team." },
  { role: 'jarvis', text: 'You have 2 urgent emails from your team, a Slack thread, and a Notion update you might want to look deeper into. Shall I dive into those apps for you?' },
];

export function BentoPair({ onNavigateConnectors }: BentoPairProps) {
  const [activeVoiceIndex, setActiveVoiceIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveVoiceIndex((prev) => (prev + 1) % VOICE_DIALOGUE.length);
    }, 3800);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="bp-section py-20 px-6 sm:px-12 max-w-[1280px] mx-auto" id="reasons">
      <div className="bp-stack flex flex-col gap-10">
        <h2 className="bp-heading text-3xl sm:text-4xl md:text-5xl font-medium tracking-tight text-[#27231D] text-left">
          Four reasons why you’ll love Jarvis
        </h2>

        {/* Row 1: Instant Access & Connectors */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Card 1: Instant access to AI (Light) */}
          <div
            className="group jcard is-light p-8 sm:p-10 rounded-[28px] flex flex-col justify-between overflow-hidden relative"
            style={{
              background: 'linear-gradient(180deg, #FFFFFF 0%, #F5F1EB 100%)',
              border: '1px solid rgba(39, 35, 29, 0.08)',
              boxShadow: '0 12px 32px -8px rgba(39, 35, 29, 0.06)',
              minHeight: '440px',
            }}
          >
            {/* Background Picture with cinematic overlay */}
            <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
              <img
                src="/keys-hotkey.webp"
                alt=""
                className="w-full h-full object-cover object-right-bottom opacity-25 group-hover:opacity-40 group-hover:scale-105 transition-all duration-700 select-none"
                loading="lazy"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
              <div
                className="absolute inset-0"
                style={{
                  background: 'linear-gradient(135deg, rgba(255,255,255,0.92) 0%, rgba(245,241,235,0.85) 50%, rgba(245,241,235,0.4) 100%)',
                }}
              />
            </div>

            <div className="relative z-10">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#27231D]/5 text-[#27231D] text-xs font-semibold uppercase tracking-wider mb-4 backdrop-blur-sm">
                <svg width="14" height="14" viewBox="0 0 16 16" fill="none" className="text-[#C9860B]">
                  <path d="M8.9 1.7 3.3 9.1h4.2l-.4 5.2 5.6-7.4H8.5z" stroke="currentColor" strokeWidth="1.5" />
                </svg>
                <span>Instant</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-medium text-[#27231D] tracking-tight mb-3">
                Instant access to AI
              </h3>
              <p className="text-[#27231D]/75 text-base leading-relaxed max-w-[420px]">
                Jarvis lives a single hotkey away — ready to quickly appear as a floating window above your other apps.
              </p>
            </div>

            <div className="relative z-10 mt-8 flex items-center justify-between">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/80 border border-neutral-200 shadow-sm backdrop-blur-md">
                <kbd className="px-2 py-1 rounded bg-neutral-100 font-mono text-xs font-semibold text-neutral-800 border border-neutral-300">⌘</kbd>
                <kbd className="px-2 py-1 rounded bg-neutral-100 font-mono text-xs font-semibold text-neutral-800 border border-neutral-300">/</kbd>
                <span className="text-xs text-neutral-600 font-medium ml-1">Summon instantly anywhere</span>
              </div>
            </div>
          </div>

          {/* Card 2: AI that works with your apps (Dark) */}
          <div
            className="group jcard is-night p-8 sm:p-10 rounded-[28px] flex flex-col justify-between overflow-hidden relative text-white"
            style={{
              background: 'linear-gradient(180deg, #18151E 0%, #0F0E14 100%)',
              border: '1px solid rgba(255, 255, 255, 0.10)',
              boxShadow: '0 16px 40px -10px rgba(0, 0, 0, 0.4)',
              minHeight: '440px',
            }}
          >
            {/* Background Picture with cinematic overlay */}
            <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
              <img
                src="/connectors-bento.webp"
                alt=""
                className="w-full h-full object-cover object-center opacity-30 group-hover:opacity-45 group-hover:scale-105 transition-all duration-700 select-none"
                loading="lazy"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
              <div
                className="absolute inset-0"
                style={{
                  background: 'linear-gradient(135deg, rgba(24,21,30,0.92) 0%, rgba(15,14,20,0.85) 60%, rgba(15,14,20,0.5) 100%)',
                }}
              />
            </div>

            <div className="relative z-10">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-white/90 text-xs font-semibold uppercase tracking-wider mb-4 backdrop-blur-sm">
                <svg width="14" height="14" viewBox="0 0 16 16" fill="none" className="text-[#A277FF]">
                  <path d="M6 1.9v3.4M10 1.9v3.4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                  <path d="M4.4 5.3h7.2v2.4a3.6 3.6 0 0 1-7.2 0z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                  <path d="M8 11.3v2.8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                </svg>
                <span>Works</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-medium text-white tracking-tight mb-3">
                AI that works with your apps
              </h3>
              <p className="text-white/75 text-base leading-relaxed max-w-[420px]">
                AI that finally knows your work across apps and can do tasks for you.
              </p>

              <button
                type="button"
                onClick={onNavigateConnectors}
                className="mt-4 inline-flex items-center gap-2 text-sm font-medium text-[#A277FF] hover:text-[#B794FF] transition-colors cursor-pointer"
              >
                <span>Explore connectors</span>
                <ExternalArrowIcon />
              </button>
            </div>

            <div className="relative z-10 mt-8 flex items-center gap-2">
              <span className="text-xs text-white/60 font-mono">Over 30+ native integrations supported</span>
            </div>
          </div>
        </div>

        {/* Row 2: Computer use & Talk */}
        <div className="grid grid-cols-1 md:grid-cols-[1fr_1.3fr] gap-6">
          {/* Card 3: Computer use (Light) */}
          <div
            className="group jcard is-light p-8 sm:p-10 rounded-[28px] flex flex-col justify-between overflow-hidden relative"
            style={{
              background: 'linear-gradient(180deg, #FFFFFF 0%, #F5F1EB 100%)',
              border: '1px solid rgba(39, 35, 29, 0.08)',
              boxShadow: '0 12px 32px -8px rgba(39, 35, 29, 0.06)',
              minHeight: '440px',
            }}
          >
            {/* Background Picture with cinematic overlay */}
            <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
              <img
                src="/bento-computer-use.webp"
                alt=""
                className="w-full h-full object-cover object-bottom opacity-25 group-hover:opacity-40 group-hover:scale-105 transition-all duration-700 select-none"
                loading="lazy"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
              <div
                className="absolute inset-0"
                style={{
                  background: 'linear-gradient(180deg, rgba(255,255,255,0.92) 0%, rgba(245,241,235,0.85) 50%, rgba(245,241,235,0.4) 100%)',
                }}
              />
            </div>

            <div className="relative z-10">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#27231D]/5 text-[#27231D] text-xs font-semibold uppercase tracking-wider mb-4 backdrop-blur-sm">
                <svg width="14" height="14" viewBox="0 0 16 16" fill="none" className="text-[#C9860B]">
                  <rect x="2.5" y="3" width="11" height="8" rx="1.5" stroke="currentColor" strokeWidth="1.5" />
                  <path d="M5.5 13.5h5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                </svg>
                <span>Automate</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-medium text-[#27231D] tracking-tight mb-3">
                Computer use
              </h3>
              <p className="text-[#27231D]/75 text-base leading-relaxed max-w-[360px]">
                Autonomous navigation and keyboard typing to complete workflows across any app on your screen.
              </p>
            </div>

            <div className="relative z-10 mt-8">
              <span className="text-xs text-[#27231D]/60 font-mono">Real mouse clicks & keyboard inputs</span>
            </div>
          </div>

          {/* Card 4: Talk to your computer (Dark Voice Mode) */}
          <div
            className="group jcard is-night p-8 sm:p-10 rounded-[28px] flex flex-col justify-between overflow-hidden relative text-white"
            style={{
              background: 'linear-gradient(180deg, #18151E 0%, #0F0E14 100%)',
              border: '1px solid rgba(255, 255, 255, 0.10)',
              boxShadow: '0 16px 40px -10px rgba(0, 0, 0, 0.4)',
              minHeight: '440px',
            }}
          >
            {/* Ambient Soundwave Aurora Background */}
            <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
              <div
                className="absolute inset-0 opacity-20 group-hover:opacity-35 transition-opacity duration-700"
                style={{
                  background: 'radial-gradient(ellipse at 70% 30%, rgba(255, 107, 107, 0.25) 0%, rgba(162, 119, 255, 0.2) 40%, transparent 80%)',
                }}
              />
              {/* Subtle animated sound wave bars in background */}
              <div className="absolute bottom-0 right-0 left-0 h-32 flex items-end justify-between px-8 gap-2 opacity-15">
                {[40, 65, 30, 85, 50, 95, 45, 70, 35, 90, 60, 40, 75, 55, 80].map((h, i) => (
                  <div
                    key={i}
                    className="w-full bg-white rounded-t-full transition-all duration-500"
                    style={{ height: `${h}%` }}
                  />
                ))}
              </div>
            </div>

            <div className="relative z-10">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-white/90 text-xs font-semibold uppercase tracking-wider mb-4 backdrop-blur-sm">
                <svg width="14" height="16" viewBox="0 0 14 19" fill="none" stroke="currentColor" strokeWidth="2" className="text-[#FF6B6B]">
                  <line x1="1" y1="6" x2="1" y2="13" strokeLinecap="round" />
                  <line x1="5" y1="1" x2="5" y2="18" strokeLinecap="round" />
                  <line x1="9" y1="5" x2="9" y2="14" strokeLinecap="round" />
                  <line x1="13" y1="8.5" x2="13" y2="11.5" strokeLinecap="round" />
                </svg>
                <span>Talk</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-medium text-white tracking-tight mb-3">
                Talk to your computer
              </h3>
              <p className="text-white/75 text-base leading-relaxed">
                Talk to Jarvis anytime you want to know something about what&apos;s happening.
              </p>
            </div>

            {/* Simulated Live Voice Mode Bubbles */}
            <div className="relative z-10 mt-8 flex flex-col gap-3 min-h-[160px] justify-end">
              {VOICE_DIALOGUE.slice(
                Math.max(0, activeVoiceIndex - 1),
                activeVoiceIndex + 1
              ).map((item, idx) => {
                const isUser = item.role === 'user';
                return (
                  <div
                    key={`${item.role}-${idx}`}
                    className={`flex items-start gap-2.5 transition-all duration-300 ${
                      isUser ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    {!isUser && (
                      <div className="w-6 h-6 rounded-full bg-[#A277FF]/20 border border-[#A277FF]/40 flex items-center justify-center shrink-0 text-[10px] font-bold text-[#A277FF]">
                        J
                      </div>
                    )}
                    <div
                      className={`px-4 py-2.5 rounded-2xl max-w-[85%] text-sm ${
                        isUser
                          ? 'bg-[#3B63F2] text-white rounded-br-sm'
                          : 'bg-white/10 text-white/90 border border-white/10 rounded-bl-sm'
                      }`}
                    >
                      {item.text}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
