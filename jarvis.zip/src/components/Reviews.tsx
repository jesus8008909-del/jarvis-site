import React from 'react';

const REVIEWS = [
  {
    text: "I used to copy things into a chat tab and describe what I was looking at. Now I just hit the hotkey and ask — it already sees the screen. That one change is the whole product.",
    avatar: "/site-assets/avatars/avatar-3.png",
    role: "Designer",
    hero: true,
  },
  {
    text: "The first assistant that answers about what I am actually looking at.",
    avatar: "/site-assets/avatars/avatar-4.png",
    role: "Vibe coder",
    hero: false,
  },
  {
    text: "It walked me through DaVinci faster than the tutorials I had open.",
    avatar: "/site-assets/avatars/avatar-5.png",
    role: "Video editor",
    hero: false,
  },
];

export function Reviews() {
  return (
    <section className="ec-section py-20 bg-[#FAF6F0]" aria-labelledby="ecr-h" id="reviews">
      <div className="ec-wrap max-w-[1280px] mx-auto px-6 sm:px-12">
        <div
          className="ec-card is-night ec-panel p-8 sm:p-14 rounded-[32px] text-white relative overflow-hidden"
          style={{
            background: 'linear-gradient(180deg, #18151F 0%, #0F0E14 100%)',
            border: '1px solid rgba(255, 255, 255, 0.12)',
            boxShadow: '0 24px 64px -16px rgba(0, 0, 0, 0.5)',
          }}
        >
          <div className="ec-body relative z-10">
            {/* Header */}
            <div className="ecr-head mb-12 text-center sm:text-left">
              <span className="ec-eyebrow text-xs font-bold uppercase tracking-wider text-[#A277FF] block mb-2">
                What our users say
              </span>
              <h2 className="ec-title ecr-title text-3xl sm:text-4xl md:text-5xl font-medium tracking-tight text-white" id="ecr-h">
                It feels like a new thing, very{' '}
                <span className="ec-hpill inline-flex items-center px-3 py-0.5 rounded-full bg-white/15 text-white border border-white/10 font-normal">
                  quickly
                </span>
                .
              </h2>
            </div>

            {/* Grid of Reviews */}
            <div className="ecr-grid grid grid-cols-1 lg:grid-cols-[1.2fr_1fr] gap-6 items-stretch">
              {/* Hero Review */}
              <div
                className="p-8 sm:p-10 rounded-[24px] bg-white/5 border border-white/10 flex flex-col justify-between"
                style={{ backdropFilter: 'blur(10px)' }}
              >
                <p className="text-xl sm:text-2xl font-normal leading-relaxed text-white/95 mb-8">
                  &ldquo;{REVIEWS[0].text}&rdquo;
                </p>
                <div className="flex items-center gap-3 pt-4 border-t border-white/10">
                  <img
                    src={REVIEWS[0].avatar}
                    alt=""
                    className="w-11 h-11 rounded-full object-cover border border-white/20"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                    }}
                  />
                  <div>
                    <span className="text-sm font-semibold text-white block">
                      {REVIEWS[0].role}
                    </span>
                    <span className="text-xs text-white/60">Verified User</span>
                  </div>
                </div>
              </div>

              {/* Side Reviews Stack */}
              <div className="ecr-side flex flex-col gap-6">
                {REVIEWS.slice(1).map((rev) => (
                  <div
                    key={rev.role}
                    className="p-7 rounded-[22px] bg-white/5 border border-white/10 flex flex-col justify-between"
                    style={{ backdropFilter: 'blur(10px)' }}
                  >
                    <p className="text-base sm:text-lg font-normal leading-relaxed text-white/90 mb-6">
                      &ldquo;{rev.text}&rdquo;
                    </p>
                    <div className="flex items-center gap-3 pt-3 border-t border-white/10">
                      <img
                        src={rev.avatar}
                        alt=""
                        className="w-9 h-9 rounded-full object-cover border border-white/20"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                        }}
                      />
                      <div>
                        <span className="text-sm font-semibold text-white block">
                          {rev.role}
                        </span>
                        <span className="text-xs text-white/60">Verified User</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
