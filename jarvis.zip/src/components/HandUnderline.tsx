import React from 'react';

export function HandUnderline({ className = "w-full" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 280 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      preserveAspectRatio="none"
      aria-hidden="true"
    >
      {/* Hand-drawn organic sketch line with natural slight curve and pen-pressure taper */}
      <path
        d="M3 13.5C45 9.2 125 7.8 195 10.2C225 11.2 255 13.8 277 12.8"
        stroke="#1E1E1E"
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Subtle organic secondary overlay stroke for ink realism */}
      <path
        d="M12 14.2C58 10.5 135 9.0 205 11.2C238 12.2 260 13.2 272 13.5"
        stroke="#171717"
        strokeWidth="2.2"
        strokeLinecap="round"
        opacity="0.85"
      />
    </svg>
  );
}
