import React, { useRef, useState, useEffect } from 'react';
import { motion, useScroll, useTransform, AnimatePresence } from 'motion/react';
import { AppleIcon, WindowsIcon } from './JarvisIcons';
import { OS } from '../types';

interface CinematicScene {
  id: string;
  number: string;
  tag: string;
  title: string;
  image: string;
  video?: string;
  question: string;
  answer: string;
  targetRect: {
    top: string;
    left: string;
    width: string;
    height: string;
    label: string;
  };
  accentColor: string;
  atmosphereGradient: string;
}

const SCENES: CinematicScene[] = [
  {
    id: 'cybernetic',
    number: '01',
    tag: 'Autonomous Cybernetics',
    title: 'Neural Vision Core',
    video: '/robot-bg.mp4',
    image: '/robot-bg.jpg',
    question: 'How does Jarvis process and perceive what is on my screen?',
    answer: 'Autonomous optical ingestion and neural spatial indexing. Jarvis observes your display in real-time, detecting interface primitives, typography, errors, and live telemetry with zero latency.',
    targetRect: {
      top: '24%',
      left: '42%',
      width: '24%',
      height: '28%',
      label: 'Neural ocular sensor & optic core',
    },
    accentColor: '#FF385C',
    atmosphereGradient: 'radial-gradient(ellipse at 50% 45%, rgba(255, 56, 92, 0.22) 0%, rgba(15, 10, 14, 0.88) 75%)',
  },
  {
    id: 'monalisa',
    number: '02',
    tag: 'Art & Visual History',
    title: 'Da Vinci’s Sfumato',
    image: '/scenes/scene_01.jpg',
    question: 'how the hell did one guy paint this?',
    answer: 'Sfumato — dozens of paper-thin glazes with no hard edges. It’s why her smile seems to shift as you look. That misty valley behind her? He invented that trick too. And bottom-right — he signed it.',
    targetRect: {
      top: '28%',
      left: '42%',
      width: '18%',
      height: '24%',
      label: 'Subtle sfumato transition layers',
    },
    accentColor: '#D4AF37',
    atmosphereGradient: 'radial-gradient(ellipse at 45% 40%, rgba(212, 175, 55, 0.15) 0%, rgba(15, 13, 20, 0.85) 75%)',
  },
  {
    id: 'orrery',
    number: '03',
    tag: 'Mechanics & Astronomy',
    title: 'The Clockwork Orrery',
    image: '/scenes/scene_02.jpg',
    question: 'what am I even looking at here?',
    answer: 'A clockwork solar system — an orrery. That’s the Sun at the centre, Earth on the third ring, and the telescope up top is how we check the model against the real sky.',
    targetRect: {
      top: '32%',
      left: '38%',
      width: '26%',
      height: '32%',
      label: 'Central brass gear train & planetary rings',
    },
    accentColor: '#60A5FA',
    atmosphereGradient: 'radial-gradient(ellipse at 50% 50%, rgba(96, 165, 250, 0.15) 0%, rgba(10, 12, 22, 0.9) 75%)',
  },
  {
    id: 'f1',
    number: '04',
    tag: 'Motorsport Telemetry',
    title: '180mph Apex Overtake',
    image: '/scenes/scene_03.jpg',
    question: 'why’s everyone losing it over this overtake?',
    answer: 'He sent it around the outside through the fastest corner on the track at ~180mph — where everyone else lifts. Zero margin for error against the barrier.',
    targetRect: {
      top: '46%',
      left: '44%',
      width: '24%',
      height: '22%',
      label: 'High-speed apex curb trajectory',
    },
    accentColor: '#F87171',
    atmosphereGradient: 'radial-gradient(ellipse at 50% 60%, rgba(248, 113, 113, 0.18) 0%, rgba(12, 10, 15, 0.88) 75%)',
  },
  {
    id: 'sarcophagus',
    number: '05',
    tag: 'Antiquities & Archaeology',
    title: 'Priest of Amun-Ra',
    image: '/scenes/scene_04.jpg',
    question: 'is someone actually in there?',
    answer: 'Was — a priest, about 3,000 years ago. The gold face is an idealised portrait so his soul could find him. The spells along the chest are from the Book of the Dead.',
    targetRect: {
      top: '26%',
      left: '41%',
      width: '20%',
      height: '34%',
      label: 'Gilded funerary mask & hieroglyphs',
    },
    accentColor: '#FBBF24',
    atmosphereGradient: 'radial-gradient(ellipse at 50% 45%, rgba(251, 191, 36, 0.18) 0%, rgba(18, 14, 10, 0.9) 75%)',
  },
  {
    id: 'hotkey',
    number: '06',
    tag: 'Native Desktop Engine',
    title: 'One Hotkey. Zero Friction.',
    image: '/keys-hotkey.webp',
    question: 'How fast can Jarvis read what’s on my active display?',
    answer: '24 milliseconds. No file uploads or screenshot snipping. Hit ⌘ / anywhere and Jarvis reads your active display pixel buffer without interrupting your workflow.',
    targetRect: {
      top: '40%',
      left: '30%',
      width: '40%',
      height: '30%',
      label: 'Local GPU screen-buffer reader',
    },
    accentColor: '#A78BFA',
    atmosphereGradient: 'radial-gradient(ellipse at 50% 50%, rgba(167, 139, 250, 0.2) 0%, rgba(14, 12, 20, 0.92) 75%)',
  },
  {
    id: 'connectors',
    number: '07',
    tag: 'App Integrations',
    title: '30+ Connected Apps',
    image: '/connectors-bento.webp',
    question: 'Cross-reference Slack, Figma and my open docs',
    answer: 'Synthesizing context across your 3 Slack threads, active Figma canvas, and Notion roadmap in real time. One assistant that lives in your work.',
    targetRect: {
      top: '25%',
      left: '25%',
      width: '50%',
      height: '45%',
      label: 'Multi-app neural connector bus',
    },
    accentColor: '#34D399',
    atmosphereGradient: 'radial-gradient(ellipse at 50% 45%, rgba(52, 211, 153, 0.2) 0%, rgba(10, 16, 14, 0.92) 75%)',
  },
];

interface CinematicScrollerProps {
  onOpenDownload?: (os?: OS) => void;
}

export function CinematicScroller({ onOpenDownload }: CinematicScrollerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [activeIdx, setActiveIdx] = useState(0);

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end end'],
  });

  // Smooth active scene index calculation based on scroll progression
  useEffect(() => {
    return scrollYProgress.on('change', (latest) => {
      const numScenes = SCENES.length;
      const index = Math.min(
        numScenes - 1,
        Math.max(0, Math.floor(latest * numScenes))
      );
      setActiveIdx(index);
    });
  }, [scrollYProgress]);

  const activeScene = SCENES[activeIdx] || SCENES[0];

  const handleJumpToScene = (index: number) => {
    if (!containerRef.current) return;
    const containerTop = containerRef.current.offsetTop;
    const containerHeight = containerRef.current.offsetHeight;
    const targetScroll = containerTop + (index / SCENES.length) * containerHeight + 20;
    window.scrollTo({ top: targetScroll, behavior: 'smooth' });
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full"
      style={{ height: `${SCENES.length * 90}vh` }}
      id="cinematic-experience"
    >
      {/* Sticky Fullscreen Stage */}
      <div className="sticky top-0 h-screen w-full overflow-hidden bg-[#0A090D] flex flex-col justify-between">
        {/* Layer 1: Background Images with crossfade & parallax scale */}
        <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden select-none">
          {SCENES.map((scene, idx) => {
            const isVisible = idx === activeIdx;
            return (
              <div
                key={scene.id}
                className="absolute inset-0 transition-opacity duration-700 ease-in-out"
                style={{
                  opacity: isVisible ? 1 : 0,
                  zIndex: isVisible ? 2 : 1,
                }}
              >
                {/* Background Media with subtle Ken Burns zoom */}
                {scene.video ? (
                  <video
                    autoPlay
                    loop
                    muted
                    playsInline
                    poster={scene.image}
                    className={`w-full h-full object-cover object-center transform transition-transform duration-[1200ms] ease-out ${
                      isVisible ? 'scale-105' : 'scale-100'
                    }`}
                    style={{
                      filter: 'brightness(0.8) contrast(1.08)',
                    }}
                  >
                    <source src={scene.video} type="video/mp4" />
                  </video>
                ) : (
                  <img
                    src={scene.image}
                    alt={scene.title}
                    className={`w-full h-full object-cover object-center transform transition-transform duration-[1200ms] ease-out ${
                      isVisible ? 'scale-105' : 'scale-100'
                    }`}
                    style={{
                      filter: 'brightness(0.7) contrast(1.1)',
                    }}
                    onError={(e) => {
                      // Fallback to hero poster if specific frame fails
                      e.currentTarget.src = '/hero-card-poster.webp';
                    }}
                  />
                )}

                {/* Cinematic Vignette & Atmospheric Lighting overlay */}
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{ background: scene.atmosphereGradient }}
                />
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    background:
                      'radial-gradient(circle at center, transparent 35%, rgba(10,9,13,0.85) 90%), linear-gradient(to top, rgba(10,9,13,0.95) 0%, transparent 40%, rgba(10,9,13,0.7) 100%)',
                  }}
                />
              </div>
            );
          })}
        </div>

        {/* Layer 2: Film Grain Texture Overlay */}
        <div
          className="absolute inset-0 pointer-events-none opacity-20 z-[3] mix-blend-overlay"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
          }}
        />

        {/* Layer 3: Interactive Target Inspection Reticle (Screen-Aware Bounding Box) */}
        <div className="absolute inset-0 z-[4] pointer-events-none">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeScene.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              transition={{ duration: 0.4 }}
              className="absolute border border-dashed rounded-xl pointer-events-none transition-all duration-500 hidden sm:block"
              style={{
                top: activeScene.targetRect.top,
                left: activeScene.targetRect.left,
                width: activeScene.targetRect.width,
                height: activeScene.targetRect.height,
                borderColor: `${activeScene.accentColor}99`,
                boxShadow: `0 0 25px ${activeScene.accentColor}33, inset 0 0 15px ${activeScene.accentColor}1A`,
              }}
            >
              {/* Corner crosshairs */}
              <div
                className="absolute -top-1.5 -left-1.5 w-3 h-3 border-t-2 border-l-2"
                style={{ borderColor: activeScene.accentColor }}
              />
              <div
                className="absolute -top-1.5 -right-1.5 w-3 h-3 border-t-2 border-r-2"
                style={{ borderColor: activeScene.accentColor }}
              />
              <div
                className="absolute -bottom-1.5 -left-1.5 w-3 h-3 border-b-2 border-l-2"
                style={{ borderColor: activeScene.accentColor }}
              />
              <div
                className="absolute -bottom-1.5 -right-1.5 w-3 h-3 border-b-2 border-r-2"
                style={{ borderColor: activeScene.accentColor }}
              />

              {/* Target Label Tag */}
              <div
                className="absolute -top-7 left-0 px-2.5 py-0.5 rounded-full text-[10px] font-mono tracking-wider text-white flex items-center gap-1.5 backdrop-blur-md shadow-md border"
                style={{
                  backgroundColor: `${activeScene.accentColor}26`,
                  borderColor: `${activeScene.accentColor}66`,
                }}
              >
                <span
                  className="w-1.5 h-1.5 rounded-full animate-ping"
                  style={{ backgroundColor: activeScene.accentColor }}
                />
                <span>{activeScene.targetRect.label}</span>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Top Cinematic Header Strip */}
        <div className="relative z-10 w-full px-6 sm:px-12 pt-24 sm:pt-28 flex items-center justify-between pointer-events-auto">
          {/* Tag & Scene Title */}
          <div className="flex items-center gap-3">
            <span
              className="px-3 py-1 rounded-full text-xs font-mono font-medium tracking-wider uppercase border backdrop-blur-md"
              style={{
                backgroundColor: 'rgba(255,255,255,0.08)',
                borderColor: 'rgba(255,255,255,0.15)',
                color: activeScene.accentColor,
              }}
            >
              {activeScene.number} · {activeScene.tag}
            </span>
            <span className="hidden sm:inline-block text-white/40 text-xs font-mono">
              SCREEN CONTEXT STREAMING
            </span>
          </div>

          {/* Quick Hotkey Indicator */}
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/15 text-xs text-white/90 backdrop-blur-md">
            <kbd className="px-1.5 py-0.5 rounded bg-white/20 font-mono text-[11px] text-white">⌘</kbd>
            <kbd className="px-1.5 py-0.5 rounded bg-white/20 font-mono text-[11px] text-white">/</kbd>
            <span className="text-white/70 text-[11px] hidden sm:inline">Inspect Screen</span>
          </div>
        </div>

        {/* Center-Bottom Floating Glass HUD Interface */}
        <div className="relative z-10 w-full max-w-4xl mx-auto px-6 pb-6 pointer-events-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeScene.id}
              initial={{ opacity: 0, y: 24, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.98 }}
              transition={{ duration: 0.35, ease: 'easeOut' }}
              className="rounded-[28px] p-6 sm:p-8 border border-white/15 shadow-[0_24px_70px_rgba(0,0,0,0.6)] backdrop-blur-2xl"
              style={{
                background:
                  'linear-gradient(135deg, rgba(28, 25, 36, 0.82) 0%, rgba(15, 13, 20, 0.92) 100%)',
              }}
            >
              {/* Question bubble (User speaks or presses hotkey) */}
              <div className="flex items-start gap-3 sm:gap-4 mb-4 pb-4 border-b border-white/10">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0 mt-0.5 shadow-sm"
                  style={{
                    background: `linear-gradient(135deg, ${activeScene.accentColor} 0%, rgba(255,255,255,0.2) 100%)`,
                  }}
                >
                  YOU
                </div>
                <div className="flex-1">
                  <span className="text-[11px] font-mono tracking-wider uppercase text-white/50 block mb-0.5">
                    Asked from active screen
                  </span>
                  <p className="text-base sm:text-xl font-normal text-white tracking-tight leading-snug">
                    &ldquo;{activeScene.question}&rdquo;
                  </p>
                </div>
              </div>

              {/* Jarvis Response Area */}
              <div className="flex items-start gap-3 sm:gap-4">
                <div className="w-8 h-8 rounded-full bg-white/10 border border-white/20 flex items-center justify-center shrink-0 mt-0.5">
                  <picture>
                    <source srcSet="/sidebar-logo.webp" type="image/webp" />
                    <img
                      src="/sidebar-logo.png"
                      alt="Jarvis"
                      className="w-5 h-auto object-contain brightness-125"
                    />
                  </picture>
                </div>

                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-semibold text-white">Jarvis</span>
                    <span
                      className="px-2 py-0.5 rounded-full text-[10px] font-mono font-medium tracking-wider uppercase"
                      style={{
                        backgroundColor: `${activeScene.accentColor}26`,
                        color: activeScene.accentColor,
                      }}
                    >
                      Instant Visual Synthesis
                    </span>
                  </div>
                  <p className="text-sm sm:text-base text-white/90 leading-relaxed font-normal">
                    {activeScene.answer}
                  </p>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Bottom Interactive Timeline Scrubber & Actions */}
        <div className="relative z-10 w-full px-6 sm:px-12 pb-6 flex flex-col sm:flex-row items-center justify-between gap-4 pointer-events-auto">
          {/* Chapter Scrubber Pills */}
          <div className="flex items-center gap-1.5 p-1 rounded-full bg-white/10 border border-white/15 backdrop-blur-md max-w-full overflow-x-auto no-scrollbar">
            {SCENES.map((scene, idx) => (
              <button
                key={scene.id}
                type="button"
                onClick={() => handleJumpToScene(idx)}
                className={`px-3 py-1.5 rounded-full text-xs font-mono transition-all cursor-pointer whitespace-nowrap ${
                  idx === activeIdx
                    ? 'bg-white text-neutral-900 font-semibold shadow-sm'
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
              >
                <span>{scene.number}</span>
                <span className="hidden md:inline ml-1.5 font-sans font-normal">
                  {scene.title}
                </span>
              </button>
            ))}
          </div>

          {/* Quick CTA button */}
          <div className="flex items-center gap-3">
            <span className="hidden lg:inline text-xs text-white/50 font-mono">
              Scroll down to continue ↓
            </span>
            <button
              type="button"
              onClick={() => onOpenDownload?.('macos')}
              className="px-5 py-2 rounded-full bg-white text-neutral-950 text-xs font-semibold hover:bg-[#FAF6F0] active:scale-95 transition-all shadow-md flex items-center gap-2 cursor-pointer"
            >
              <AppleIcon />
              <span>Get Jarvis Free</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
export default CinematicScroller;
