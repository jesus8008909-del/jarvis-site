import React, { useState, useRef, useLayoutEffect, useEffect, useCallback } from 'react';

const wordmarkSrc = (key: string) => `/brand-marks/${key}-wordmark.svg`;

function LightningIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <path
        d="M8.9 1.7 3.3 9.1h4.2l-.4 5.2 5.6-7.4H8.5z"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinejoin="round"
      />
    </svg>
  );
}

interface Item {
  k: string;
  name: string;
  wm: number;
  wo?: number;
  them: string;
  pre?: string;
  lead: string;
  us: string;
}

const ITEMS: Item[] = [
  {
    k: 'chatgpt',
    name: 'ChatGPT',
    wm: 1,
    them: 'Waits in its own window. You bring it the context.',
    lead: 'Already there',
    us: ', looking at the same screen you are.',
  },
  {
    k: 'claude',
    name: 'Claude',
    wm: 0.84,
    wo: 1.3,
    them: 'A brilliant answer, in a tab you have to go to.',
    lead: 'The same model',
    us: " in a bar that's already there.",
  },
  {
    k: 'cursor',
    name: 'Cursor',
    wm: 0.97,
    them: 'Writes the code for you.',
    pre: 'Teaches you to ',
    lead: 'handle the rest',
    us: ', getting API keys, setting up a database, etc.',
  },
  {
    k: 'cluely',
    name: 'Cluely',
    wm: 0.86,
    wo: 1.08,
    them: 'Sits in on your meetings.',
    lead: 'Explains anything',
    us: ' on your screen, all day, meeting or not.',
  },
  {
    k: 'perplexity',
    name: 'Perplexity',
    wm: 1.1,
    wo: 1.35,
    them: 'Great at doing research, but useless when it takes you two minutes to get an answer.',
    lead: 'Is already there',
    us: ', so any question you have can be answered in seconds.',
  },
];

export function JarvisVs() {
  const [activeTab, setActiveTab] = useState(0);
  const [displayedTab, setDisplayedTab] = useState(0);
  const [isFadingIn, setIsFadingIn] = useState(true);
  const tabsRef = useRef<HTMLDivElement>(null);
  const [inkStyle, setInkStyle] = useState({ left: 0, width: 0 });

  const updateInk = useCallback(() => {
    const el = tabsRef.current;
    if (!el) return;
    const buttons = el.querySelectorAll<HTMLButtonElement>('.ecv-tab');
    const target = buttons[activeTab];
    if (target) {
      setInkStyle({
        left: target.offsetLeft,
        width: target.offsetWidth,
      });
    }
  }, [activeTab]);

  useLayoutEffect(updateInk, [updateInk]);

  useEffect(() => {
    const el = tabsRef.current;
    if (!el || typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', updateInk);
      return () => window.removeEventListener('resize', updateInk);
    }
    const ro = new ResizeObserver(updateInk);
    ro.observe(el);
    el.querySelectorAll('.ecv-tab').forEach((b) => ro.observe(b));
    return () => ro.disconnect();
  }, [updateInk]);

  useEffect(() => {
    if (activeTab === displayedTab) return;
    setIsFadingIn(false);
    const t = setTimeout(() => {
      setDisplayedTab(activeTab);
      setIsFadingIn(true);
    }, 400);
    return () => clearTimeout(t);
  }, [activeTab, displayedTab]);

  const activeItem = ITEMS[displayedTab];

  return (
    <section className="ec-section py-20" aria-labelledby="ecv-h" id="compare">
      <div className="ec-wrap max-w-[1280px] mx-auto px-6 sm:px-12">
        <div className="ecv-head text-center mb-10">
          <h2 className="ec-title ecv-title text-3xl sm:text-4xl md:text-5xl font-medium tracking-tight text-[#27231D] mb-3" id="ecv-h">
            A chatbot answers.
            <br />
            Jarvis is always there.
          </h2>
          <p className="ec-sub text-base sm:text-lg text-[#27231D]/70 max-w-[580px] mx-auto">
            Other AI tools are either stuck in a chat window or have a narrow purpose. Jarvis is everything
          </p>
        </div>

        {/* Tab Pills */}
        <div className="ecv-tabsview flex justify-center mb-12">
          <div
            className="ecv-tabs relative inline-flex items-center p-1.5 rounded-full bg-[#EFEBE4] border border-[#27231D]/10"
            ref={tabsRef}
            role="tablist"
            aria-label="Compare Jarvis with"
          >
            <span
              className="ecv-ink absolute top-1.5 bottom-1.5 rounded-full bg-white shadow-[0_2px_8px_rgba(0,0,0,0.08)] transition-all duration-300 ease-out pointer-events-none"
              style={{
                transform: `translateX(${inkStyle.left}px)`,
                width: inkStyle.width,
              }}
              aria-hidden="true"
            />
            {ITEMS.map((item, idx) => (
              <button
                key={item.k}
                type="button"
                role="tab"
                id={`ecv-tab-${item.k}`}
                aria-selected={idx === activeTab}
                aria-controls={`ecv-panel-${item.k}`}
                tabIndex={idx === activeTab ? 0 : -1}
                className={`ecv-tab relative z-10 px-5 py-2.5 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                  idx === activeTab ? 'opacity-100' : 'opacity-60 hover:opacity-90'
                }`}
                onClick={() => setActiveTab(idx)}
              >
                <img
                  className="ecv-tabmark h-4 sm:h-5 w-auto object-contain"
                  src={wordmarkSrc(item.k)}
                  alt={item.name}
                  loading="lazy"
                />
              </button>
            ))}
          </div>
        </div>

        {/* Side-by-Side Comparison Cards */}
        <div className="ecv-row grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
          {/* Them */}
          <div className="ecv-side flex">
            <div
              className="jcard is-light ecv-card w-full p-8 sm:p-12 rounded-[28px] flex flex-col justify-center text-center"
              style={{
                background: '#FFFFFF',
                border: '1px solid rgba(39, 35, 29, 0.08)',
                boxShadow: '0 12px 36px -8px rgba(39, 35, 29, 0.06)',
                minHeight: '260px',
              }}
            >
              <div
                className={`ec-body ecv-fade transition-opacity duration-300 ${
                  isFadingIn ? 'opacity-100' : 'opacity-0'
                }`}
                role="tabpanel"
                id={`ecv-panel-${activeItem.k}`}
                aria-labelledby={`ecv-tab-${activeItem.k}`}
              >
                <div className="flex justify-center mb-6">
                  <img
                    className="ecv-wordmark h-6 sm:h-7 w-auto object-contain"
                    src={wordmarkSrc(activeItem.k)}
                    alt={activeItem.name}
                    loading="lazy"
                  />
                </div>
                <p className="ecv-line text-lg sm:text-xl text-[#27231D]/80 font-normal leading-relaxed max-w-[420px] mx-auto">
                  {activeItem.them}
                </p>
              </div>
            </div>
          </div>

          {/* Jarvis */}
          <div className="ecv-side flex">
            <div
              className="ec-card is-night ecv-card w-full p-8 sm:p-12 rounded-[28px] flex flex-col justify-center text-center relative overflow-hidden"
              style={{
                background: 'linear-gradient(180deg, #17141F 0%, #0F0E14 100%)',
                border: '1px solid rgba(255, 255, 255, 0.12)',
                boxShadow: '0 20px 48px -10px rgba(0, 0, 0, 0.45)',
                minHeight: '260px',
              }}
            >
              <div
                className={`ec-body transition-opacity duration-300 ${
                  isFadingIn ? 'opacity-100' : 'opacity-0'
                }`}
              >
                <div className="flex justify-center mb-6">
                  <picture>
                    <source srcSet="/sidebar-logo.webp" type="image/webp" />
                    <img
                      className="ecv-mark h-6 sm:h-7 w-auto object-contain brightness-125"
                      src="/sidebar-logo.png"
                      alt="Jarvis"
                      width="133"
                      height="36"
                    />
                  </picture>
                </div>
                <p className="ecv-line text-lg sm:text-xl text-white/90 font-normal leading-relaxed max-w-[440px] mx-auto">
                  {activeItem.pre}
                  <span className="ec-pill inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-white/15 text-white font-medium mx-1.5 border border-white/10">
                    <LightningIcon />
                    {activeItem.lead}
                  </span>
                  {activeItem.us}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
export default JarvisVs;
