import React from 'react';

const CONNECTOR_ICONS = [
  'gmail.png',
  'github.png',
  'slack.png',
  'google-drive.png',
  'google-calendar.png',
  'figma.png',
  'linear.png',
  'clickup.png',
  'microsoft-outlook.png',
  'google-sheets.png',
  'airtable.png',
  'asana.png',
  'spotify.png',
  'todoist.png',
  'apple-notes.png',
  'apple-calendar.png',
  'apple-clock.png',
  'apple-music.png',
  'apple-reminders.png',
];

interface AppIntegrationsProps {
  onOpenConnectors?: () => void;
}

export function AppIntegrations({ onOpenConnectors }: AppIntegrationsProps) {
  return (
    <section className="py-24 px-6 sm:px-12 bg-[#FAF6F0] relative overflow-hidden" id="integrations">
      <div className="max-w-[1280px] mx-auto text-center relative">
        <span className="text-xs font-bold uppercase tracking-wider text-[#C9860B] block mb-2">
          App integrations
        </span>
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-medium tracking-tight text-[#27231D] mb-4">
          Connects to your favorite tools
        </h2>
        <p className="text-base sm:text-lg text-[#27231D]/70 max-w-[540px] mx-auto mb-14">
          AI that finally knows your work across apps and can do tasks for you.
        </p>

        {/* Dynamic Connector Icons Wall */}
        <div className="relative w-full max-w-[1040px] mx-auto rounded-[32px] p-8 sm:p-14 overflow-hidden border border-[#27231D]/10 bg-white/60 shadow-[0_16px_40px_-12px_rgba(0,0,0,0.06)]">
          {/* Subtle Grid of floating icons in background */}
          <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-6 sm:gap-8 items-center justify-items-center opacity-90 mb-12">
            {CONNECTOR_ICONS.concat(CONNECTOR_ICONS.slice(0, 5)).map((icon, idx) => (
              <div
                key={`${icon}-${idx}`}
                className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-white shadow-sm border border-neutral-100 p-2.5 flex items-center justify-center hover:scale-110 hover:shadow-md transition-all duration-200 cursor-pointer"
              >
                <img
                  src={`/connector-icons/${icon}`}
                  alt=""
                  className="w-full h-full object-contain"
                  loading="lazy"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                  }}
                />
              </div>
            ))}
          </div>

          {/* Centered Frosted Glass Callout Card */}
          <div className="relative z-10 max-w-[540px] mx-auto p-6 sm:p-8 rounded-[24px] bg-[#1E1B18] text-white shadow-2xl border border-white/15">
            <h3 className="text-xl sm:text-2xl font-medium text-white mb-2">
              Over 30+ native connectors
            </h3>
            <p className="text-sm text-white/70 mb-6 leading-relaxed">
              Google Workspace, Microsoft 365, Notion, Slack, Figma, GitHub, Linear, and your native macOS &amp; Windows system apps.
            </p>
            <button
              type="button"
              onClick={onOpenConnectors}
              className="px-6 py-2.5 rounded-full bg-white text-[#1E1B18] text-sm font-semibold hover:bg-[#FAF6F0] active:scale-[0.98] transition-all cursor-pointer shadow-md"
            >
              Check out integrations
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
export default AppIntegrations;
