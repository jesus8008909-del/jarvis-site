import React, { ReactNode } from 'react';
import { motion } from 'motion/react';

interface ScrollRevealProps {
  children: ReactNode;
  delay?: number;
  yOffset?: number;
  duration?: number;
  className?: string;
  id?: string;
  threshold?: number;
}

export function ScrollReveal({
  children,
  delay = 0,
  yOffset = 28,
  duration = 0.75,
  className = '',
  id,
  threshold = 0.12,
}: ScrollRevealProps) {
  return (
    <motion.div
      id={id}
      initial={{ opacity: 0, y: yOffset }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: threshold, margin: '0px 0px -50px 0px' }}
      transition={{
        duration,
        delay,
        ease: [0.22, 1, 0.36, 1], // Custom cubic-bezier for refined, silky smooth easing
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export default ScrollReveal;
