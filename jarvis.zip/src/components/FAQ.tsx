import React, { useState } from 'react';
import { ChevronDown, Search } from 'lucide-react';
import rawFaqData from '../data/faqData.json';

interface FAQItem {
  q: string;
  a: string;
}

const FAQ_LIST: FAQItem[] = rawFaqData;

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const [searchQuery, setSearchQuery] = useState('');

  const toggleItem = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const filteredFaqs = FAQ_LIST.filter(
    (item) =>
      item.q.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.a.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <section className="py-24 px-6 sm:px-12 bg-[#FAF6F0]" id="faq">
      <div className="max-w-[960px] mx-auto">
        <div className="text-center mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-[#C9860B] block mb-2">
            Got questions?
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-medium tracking-tight text-[#27231D] mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-base sm:text-lg text-[#27231D]/70 max-w-[540px] mx-auto mb-8">
            Everything you need to know about Jarvis, security, supported platforms, and pricing.
          </p>

          {/* Quick Search */}
          <div className="relative max-w-[420px] mx-auto">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#27231D]/40" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search 23 questions..."
              className="w-full pl-11 pr-4 py-2.5 rounded-full bg-white border border-[#27231D]/15 text-sm text-[#27231D] placeholder:text-[#27231D]/40 focus:outline-none focus:ring-2 focus:ring-[#27231D]/20 shadow-sm"
            />
          </div>
        </div>

        {/* Accordion list */}
        <div className="space-y-3">
          {filteredFaqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={faq.q}
                className="rounded-2xl border border-[#27231D]/10 bg-white overflow-hidden transition-all shadow-[0_2px_8px_rgba(0,0,0,0.02)]"
              >
                <button
                  type="button"
                  onClick={() => toggleItem(idx)}
                  className="w-full p-5 sm:p-6 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-[#FAF8F5]/60 transition-colors"
                  aria-expanded={isOpen}
                >
                  <span className="text-base sm:text-lg font-medium text-[#27231D] tracking-tight">
                    {faq.q}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 shrink-0 text-[#27231D]/60 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-[#27231D]' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-6 pt-1 text-sm sm:text-base leading-relaxed text-[#27231D]/75 border-t border-[#27231D]/5">
                    <p className="whitespace-pre-line">{faq.a}</p>
                  </div>
                )}
              </div>
            );
          })}

          {filteredFaqs.length === 0 && (
            <div className="p-8 text-center text-[#27231D]/60 bg-white rounded-2xl border border-[#27231D]/10">
              No questions found matching &ldquo;{searchQuery}&rdquo;.
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
