import React, { useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface UseCaseCard {
  id: string;
  tag: string;
  title: string;
  subtitle: string;
  bgGradient: string;
  textColor: string;
  tagBg: string;
  question: string;
  answer: string;
  accentColor: string;
}

const USE_CASES: UseCaseCard[] = [
  {
    id: 'biology',
    tag: 'Biology',
    title: 'Teaches you biology',
    subtitle: 'Every diagram, every cycle — explained where you meet it.',
    bgGradient: 'linear-gradient(135deg, #FFE8E8 0%, #FFD1D1 100%)',
    textColor: '#5A1E1E',
    tagBg: 'rgba(90, 30, 30, 0.1)',
    question: 'What chamber is this right here?',
    answer: 'This is the left atrium of the heart, receiving oxygenated blood from the pulmonary veins.',
    accentColor: '#E03131',
  },
  {
    id: 'tools',
    tag: 'Mastery',
    title: 'Learn Claude, ChatGPT, and Higgsfield in minutes, not hours',
    subtitle: "The Claude desktop app, open on 'Back at it, Michael'",
    bgGradient: 'linear-gradient(135deg, #F3E8FF 0%, #E9D5FF 100%)',
    textColor: '#3B1E54',
    tagBg: 'rgba(59, 30, 84, 0.1)',
    question: 'How do I switch the underlying model?',
    answer: 'To switch the model, click Fable 5 in the bottom right corner of the prompt box.',
    accentColor: '#9333EA',
  },
  {
    id: 'notes',
    tag: 'Notes',
    title: 'Have an always on notes partner',
    subtitle: 'Think out loud. It writes the version you can actually use.',
    bgGradient: 'linear-gradient(135deg, #FEF3C7 0%, #FDE68A 100%)',
    textColor: '#593E00',
    tagBg: 'rgba(89, 62, 0, 0.1)',
    question: 'Clean this brain-dump up into 3 action items',
    answer: '1. Finalize Q3 pricing grid\n2. Ship API migration notes\n3. Review design tokens with Sarah',
    accentColor: '#D97706',
  },
  {
    id: 'problem',
    tag: 'Engineering',
    title: 'Works the problem with you',
    subtitle: 'Sketch the system, check the maths, catch the flaw early.',
    bgGradient: 'linear-gradient(135deg, #E0F2FE 0%, #BAE6FD 100%)',
    textColor: '#073B4C',
    tagBg: 'rgba(7, 59, 76, 0.1)',
    question: "What's wrong here Jarvis?",
    answer: 'Almost no flow through this second bypass channel — check the pressure drop ratio.',
    accentColor: '#0284C7',
  },
  {
    id: 'design',
    tag: 'Creative',
    title: 'Turns you into a designer',
    subtitle: 'Canva, Figma, Illustrator — guided until it is instinct.',
    bgGradient: 'linear-gradient(135deg, #DCFCE7 0%, #BBF7D0 100%)',
    textColor: '#144A27',
    tagBg: 'rgba(20, 74, 39, 0.1)',
    question: 'How do I add a smooth dissolve between clips?',
    answer: 'Click the 3 dots on the cut in the timeline, then select Dissolve transition.',
    accentColor: '#16A34A',
  },
  {
    id: 'info',
    tag: 'Everyday',
    title: 'Information at your fingertips',
    subtitle: 'Ask about anything that crosses your mind, right where you are.',
    bgGradient: 'linear-gradient(135deg, #F5F3FF 0%, #EDE9FE 100%)',
    textColor: '#2E1065',
    tagBg: 'rgba(46, 16, 101, 0.1)',
    question: "What's this frog called?",
    answer: 'A red-eyed tree frog (Agalychnis callidryas), native to Neotropical rainforests.',
    accentColor: '#6366F1',
  },
];

export function UseCaseRail() {
  const scrollRef = useRef<HTMLDivElement>(null);

  const handleScroll = (direction: 'left' | 'right') => {
    if (!scrollRef.current) return;
    const scrollAmount = 380;
    scrollRef.current.scrollBy({
      left: direction === 'left' ? -scrollAmount : scrollAmount,
      behavior: 'smooth',
    });
  };

  return (
    <section className="uc-section py-20 px-6 sm:px-12 max-w-[1400px] mx-auto" id="use-cases">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-[#C9860B] block mb-2">
            Everyday superpowers
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-medium tracking-tight text-[#27231D]">
            Learn any skill in hours not weeks
          </h2>
        </div>

        {/* Scroll Arrows */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => handleScroll('left')}
            className="w-10 h-10 rounded-full border border-[#27231D]/15 flex items-center justify-center text-[#27231D] hover:bg-[#27231D]/5 transition-colors cursor-pointer"
            aria-label="Scroll left"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            type="button"
            onClick={() => handleScroll('right')}
            className="w-10 h-10 rounded-full border border-[#27231D]/15 flex items-center justify-center text-[#27231D] hover:bg-[#27231D]/5 transition-colors cursor-pointer"
            aria-label="Scroll right"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Scrolling Carousel Cards */}
      <div
        ref={scrollRef}
        className="flex gap-6 overflow-x-auto pb-6 scrollbar-none snap-x snap-mandatory"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {USE_CASES.map((card) => (
          <div
            key={card.id}
            className="snap-start shrink-0 w-[320px] sm:w-[380px] p-7 rounded-[26px] flex flex-col justify-between shadow-[0_8px_24px_-4px_rgba(0,0,0,0.06)] border border-black/5 select-none transition-transform hover:-translate-y-1"
            style={{
              background: card.bgGradient,
              color: card.textColor,
              minHeight: '380px',
            }}
          >
            <div>
              <span
                className="inline-block text-xs font-semibold px-2.5 py-1 rounded-full uppercase tracking-wider mb-4"
                style={{ backgroundColor: card.tagBg }}
              >
                {card.tag}
              </span>
              <h3 className="text-xl sm:text-2xl font-medium tracking-tight mb-2 leading-snug">
                {card.title}
              </h3>
              <p className="text-sm opacity-80 leading-relaxed">{card.subtitle}</p>
            </div>

            {/* Interactive Dialogue Mock */}
            <div
              className="mt-6 p-4 rounded-2xl bg-white/70 backdrop-blur-md border border-white/60 shadow-sm flex flex-col gap-2.5"
              style={{ color: '#1E1B18' }}
            >
              <div className="flex items-start gap-2 text-xs font-medium text-neutral-600">
                <span className="font-bold text-neutral-900">You:</span>
                <span>{card.question}</span>
              </div>
              <div className="flex items-start gap-2 text-xs leading-relaxed text-neutral-800 border-t border-neutral-200/60 pt-2">
                <span className="font-bold" style={{ color: card.accentColor }}>
                  Jarvis:
                </span>
                <span className="whitespace-pre-line">{card.answer}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
