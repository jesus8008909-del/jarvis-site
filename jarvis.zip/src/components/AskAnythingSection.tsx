import React, { useState } from 'react';

interface ClickableItem {
  id: string;
  name: string;
  category: string;
  question: string;
  answer: string;
  tag: string;
  icon: string;
}

const ITEMS: ClickableItem[] = [
  {
    id: 'formula',
    name: 'Euler’s Identity',
    category: 'Mathematics',
    question: 'e^(iπ) + 1 = 0 — what makes this equation so profound?',
    answer: 'It links the five most fundamental mathematical constants (e, i, π, 1, 0) using only addition, multiplication, and exponentiation.',
    tag: 'Formula',
    icon: '∑',
  },
  {
    id: 'chart',
    name: 'Candlestick Chart',
    category: 'Finance',
    question: 'What pattern is forming here on the 4-hour timeframe?',
    answer: 'A bullish falling wedge with declining volume, indicating seller exhaustion and likely upward breakout near the $4.20 resistance.',
    tag: 'Chart',
    icon: '📈',
  },
  {
    id: 'code',
    name: 'Memory Leak Bug',
    category: 'Code',
    question: 'Why is this React component re-rendering infinitely?',
    answer: 'You passed an inline object to the useEffect dependency array without useMemo, creating a new reference on every single render cycle.',
    tag: 'Code',
    icon: '⚡',
  },
  {
    id: 'painting',
    name: 'Girl with a Pearl Earring',
    category: 'Art',
    question: 'Is she wearing an actual pearl earring?',
    answer: 'Recent scientific imaging shows it’s an illusion made of just two quick brushstrokes of lead-white paint; Vermeer didn’t even paint a hook.',
    tag: 'Masterpiece',
    icon: '🎨',
  },
];

interface AskAnythingSectionProps {
  onOpenDownload?: (os?: any) => void;
}

export function AskAnythingSection({ onOpenDownload: _ }: AskAnythingSectionProps = {}) {
  const [activeItem, setActiveItem] = useState<ClickableItem>(ITEMS[0]);

  return (
    <section className="aay py-24 px-6 sm:px-12 relative overflow-hidden bg-[#FAF6F0]" id="ask-anything">
      <div className="max-w-[1280px] mx-auto text-center">
        {/* Title */}
        <h2 className="text-4xl sm:text-5xl md:text-6xl font-medium tracking-tight text-[#27231D] mb-4">
          Ask about anything you see
        </h2>
        <p className="text-lg text-[#27231D]/70 max-w-[620px] mx-auto mb-12">
          Point at any part of your screen and press the hotkey. Jarvis explains, translates,
          calculates, and finds whatever you&apos;re looking at.
        </p>

        {/* Interactive Selection Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-[800px] mx-auto mb-8">
          {ITEMS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveItem(item)}
              className={`p-3.5 rounded-2xl border transition-all text-left flex items-center gap-3 cursor-pointer ${
                activeItem.id === item.id
                  ? 'bg-[#1E1B18] text-[#FAF6F0] border-[#1E1B18] shadow-md scale-[1.02]'
                  : 'bg-white/80 text-[#27231D] border-[#27231D]/10 hover:bg-white'
              }`}
            >
              <span className="text-2xl">{item.icon}</span>
              <div className="flex flex-col">
                <span className="text-[11px] opacity-70 font-semibold uppercase tracking-wider">
                  {item.category}
                </span>
                <span className="text-sm font-medium tracking-tight truncate">
                  {item.name}
                </span>
              </div>
            </button>
          ))}
        </div>

        {/* Floating Screen Context Preview */}
        <div className="max-w-[840px] mx-auto p-6 sm:p-8 rounded-[28px] bg-[#17141E] text-white border border-white/10 shadow-[0_24px_50px_rgba(0,0,0,0.3)] text-left relative overflow-hidden">
          <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#38D9A9] animate-pulse" />
              <span className="text-xs uppercase font-semibold tracking-wider text-white/70">
                Visual Inspection Mode · Screen Aware
              </span>
            </div>
            <span className="text-xs px-2.5 py-1 rounded-full bg-white/10 text-white/80 font-mono">
              {activeItem.tag}
            </span>
          </div>

          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <span className="px-2 py-0.5 rounded bg-[#A277FF]/20 text-[#A277FF] text-xs font-bold shrink-0 mt-0.5">
                QUESTION
              </span>
              <p className="text-base sm:text-lg font-medium text-white/95 leading-relaxed">
                {activeItem.question}
              </p>
            </div>

            <div className="flex items-start gap-3 pt-2">
              <span className="px-2 py-0.5 rounded bg-[#38D9A9]/20 text-[#38D9A9] text-xs font-bold shrink-0 mt-0.5">
                JARVIS
              </span>
              <p className="text-sm sm:text-base text-white/80 leading-relaxed font-normal">
                {activeItem.answer}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
