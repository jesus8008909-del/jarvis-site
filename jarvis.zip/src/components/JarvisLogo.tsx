import React from 'react';

export function JarvisLogo({ className = "w-7 h-7" }: { className?: string }) {
  return (
    <svg 
      viewBox="0 0 32 32" 
      fill="currentColor" 
      className={className} 
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Jarvis Logo"
    >
      {/* Cloud-like rounded silhouette matching the screenshot icon */}
      <path d="M9.8 24C6.6 24 4 21.4 4 18.2c0-2.9 2.1-5.3 5-5.7C9.9 8.2 13.5 5 18 5c4.7 0 8.6 3.5 9 8.2 3 .5 5 2.8 5 5.8 0 3.3-2.7 6-6 6H9.8z" />
    </svg>
  );
}

export function WindowsIcon({ className = "w-4 h-4" }: { className?: string }) {
  return (
    <svg 
      viewBox="0 0 88 88" 
      fill="currentColor" 
      className={className}
      aria-hidden="true"
    >
      {/* Microsoft Windows 4-tile modern flat emblem */}
      <path d="M0 12.402l35.689-4.86v33.879H0V12.402zm35.689 33.649v33.914L0 75.059V46.051h35.689zm5.322-39.274L88 0v41.421H41.011V6.777zm46.989 39.274V88l-46.989-6.727V46.051H88z" />
    </svg>
  );
}

export function AppleIcon({ className = "w-4 h-4" }: { className?: string }) {
  return (
    <svg 
      viewBox="0 0 170 170" 
      fill="currentColor" 
      className={className}
      aria-hidden="true"
    >
      <path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.19-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.75 3.17-5.26 2.13-9.5 3.24-12.74 3.35-4.35.13-9.16-1.9-14.42-6.08-3.69-3.04-7.66-7.85-11.91-14.42-6.19-9.59-10.92-20.73-14.19-33.43-3.27-12.7-4.9-24.32-4.9-34.87 0-14.36 3.69-26.06 11.06-35.1 7.37-9.04 16.59-13.67 27.67-13.89 5.35 0 11.22 1.37 17.62 4.11 6.4 2.74 10.37 4.16 11.91 4.28 1.42-.12 5.56-1.59 12.43-4.41 6.87-2.82 12.48-4.11 16.83-3.87 12.63.66 22.86 5.44 30.69 14.35-10.98 6.64-16.36 15.89-16.15 27.75.22 9.59 3.92 17.66 11.1 24.21 7.18 6.54 15.69 10.23 25.53 11.06-2.17 6.63-4.9 13.52-8.18 20.67zM119.22 33.64c0-7.39 2.67-14.32 8.01-20.78 5.34-6.47 11.97-10.74 19.89-12.82.76 2.5 1.14 5.09 1.14 7.76 0 7.39-2.73 14.47-8.19 21.23-5.46 6.77-12.28 11.16-20.46 13.19-.22-2.73-.39-5.59-.39-8.58z" />
    </svg>
  );
}

export function LinuxIcon({ className = "w-4 h-4" }: { className?: string }) {
  return (
    <svg 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
      aria-hidden="true"
    >
      <path d="M12 2a4 4 0 0 0-4 4v3a4 4 0 0 0 8 0V6a4 4 0 0 0-4-4Z"/>
      <path d="M12 13c-4.4 0-8 3.6-8 8v1h16v-1c0-4.4-3.6-8-8-8Z"/>
      <circle cx="9.5" cy="6.5" r=".5" fill="currentColor"/>
      <circle cx="14.5" cy="6.5" r=".5" fill="currentColor"/>
    </svg>
  );
}
