import React, { useState, useEffect, useRef } from 'react';
import { AppleIcon, WindowsIcon } from './JarvisIcons';
import { OS } from '../types';

interface HeroProps {
  onOpenDownload: (os?: OS) => void;
  onLaunchSimulator?: () => void;
}

interface Scene {
  id: string;
  name: string;
  q: string;
  a: string;
}

const SCENES: Scene[] = [
  {
    id: 'monalisa',
    name: 'Mona Lisa',
    q: 'how the hell did one guy paint this?',
    a: 'Sfumato — dozens of paper-thin glazes with no hard edges. It’s why her smile seems to shift as you look. That misty valley behind her? He invented that trick too. And bottom-right — he signed it.',
  },
  {
    id: 'space',
    name: 'Orrery',
    q: 'what am I even looking at here?',
    a: 'A clockwork solar system — an orrery. That’s the Sun at the centre, Earth on the third ring, and the telescope up top is how we check the model against the real sky.',
  },
  {
    id: 'f1',
    name: 'F1 Overtake',
    q: 'why’s everyone losing it over this overtake?',
    a: 'He sent it around the outside through the fastest corner on the track at ~180mph — where everyone else lifts.',
  },
  {
    id: 'sarcophagus',
    name: 'Sarcophagus',
    q: 'is someone actually in there?',
    a: 'Was — a priest, about 3,000 years ago. The gold face is an idealised portrait so his soul could find him, and the crossed hands mark him as justified before Osiris.',
  },
];

const AVATARS = [
  '/site-assets/avatars/avatar-1.png',
  '/site-assets/avatars/avatar-2.png',
  '/site-assets/avatars/avatar-3.png',
  '/site-assets/avatars/avatar-4.png',
  '/site-assets/avatars/avatar-5.png',
];

export function Hero({ onOpenDownload }: HeroProps) {
  const [activeSceneIndex, setActiveSceneIndex] = useState(0);
  const [displayedAnswer, setDisplayedAnswer] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const scene = SCENES[activeSceneIndex];

  // Cycle scenes every 7 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveSceneIndex((prev) => (prev + 1) % SCENES.length);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  // Typewriter effect for scene change
  useEffect(() => {
    setDisplayedAnswer('');
    setIsTyping(true);
    let currentText = '';
    const fullText = scene.a;
    let charIndex = 0;

    const typeTimer = setInterval(() => {
      if (charIndex < fullText.length) {
        currentText += fullText[charIndex];
        setDisplayedAnswer(currentText);
        charIndex++;
      } else {
        setIsTyping(false);
        clearInterval(typeTimer);
      }
    }, 14);

    return () => clearInterval(typeTimer);
  }, [scene]);

  return (
    <section
      id="hero"
      className="relative w-full min-h-[95vh] flex items-center justify-center overflow-hidden"
      style={{
        background: 'transparent',
        color: '#FFFFFF',
        fontFamily: 'General Sans, -apple-system, sans-serif',
      }}
    >
      <div
        className="w-full max-w-[1600px] box-border grid grid-cols-1 lg:grid-cols-[1.1fr_auto] gap-12 lg:gap-16 items-center px-6 sm:px-12 pt-32 pb-20"
      >
        {/* Left Column: Heading & Copy */}
        <div className="flex flex-col items-start text-left max-w-[620px]">
          {/* Main Title with exact handwritten underline */}
          <h1
            style={{
              fontSize: 'clamp(40px, 4.1vw, 56px)',
              fontWeight: 500,
              lineHeight: 1.08,
              letterSpacing: '-0.03em',
              color: '#FFFFFF',
              margin: 0,
            }}
          >
            AI for all the small questions that{' '}
            <span
              style={{
                position: 'relative',
                display: 'inline-block',
                whiteSpace: 'nowrap',
              }}
            >
              mean a lot
              <svg
                aria-hidden="true"
                viewBox="0 0 300 28"
                preserveAspectRatio="none"
                style={{
                  position: 'absolute',
                  left: '-3%',
                  width: '106%',
                  bottom: '-0.27em',
                  height: '0.44em',
                  overflow: 'visible',
                  pointerEvents: 'none',
                }}
              >
                <defs>
                  <filter id="ulFray" x="-15%" y="-60%" width="130%" height="220%">
                    <feTurbulence
                      type="fractalNoise"
                      baseFrequency="0.9 0.7"
                      numOctaves="1"
                      seed="7"
                      stitchTiles="stitch"
                      result="n"
                    />
                    <feDisplacementMap
                      in="SourceGraphic"
                      in2="n"
                      scale="1.6"
                      xChannelSelector="R"
                      yChannelSelector="G"
                    />
                  </filter>
                </defs>
                <path
                  d="M4 12 C 100 9, 205 14, 298 24"
                  fill="none"
                  stroke="#FF385C"
                  strokeWidth="4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  vectorEffect="non-scaling-stroke"
                  filter="url(#ulFray)"
                />
              </svg>
            </span>
          </h1>

          {/* Subtitle */}
          <p
            style={{
              fontSize: '17px',
              lineHeight: 1.64,
              letterSpacing: '-0.01em',
              color: 'rgba(255, 255, 255, 0.82)',
              marginTop: '22px',
              maxWidth: '560px',
            }}
          >
            AI is not supposed to live in a window. Jarvis is always there on your screen.
            Connect it to your apps so it can learn and do more for you.
          </p>

          {/* Action Row: Download Buttons */}
          <div className="mt-8 flex flex-col items-start gap-3.5">
            <div className="flex flex-wrap items-center gap-3">
              {/* Download for macOS */}
              <button
                type="button"
                onClick={() => onOpenDownload('macos')}
                className="inline-flex items-center gap-2.5 px-6 py-3 rounded-full text-[15px] font-semibold transition-all duration-150 hover:bg-neutral-100 active:scale-[0.98] cursor-pointer shadow-lg"
                style={{
                  backgroundColor: '#FFFFFF',
                  color: '#0A090D',
                }}
                id="hero-download-mac-btn"
              >
                <AppleIcon className="w-4 h-4 text-neutral-900" />
                <span>Download for macOS</span>
              </button>

              {/* Download for Windows */}
              <button
                type="button"
                onClick={() => onOpenDownload('windows')}
                className="inline-flex items-center gap-2.5 px-6 py-3 rounded-full text-[15px] font-medium transition-all duration-150 hover:bg-white/15 active:scale-[0.98] cursor-pointer border border-white/20 backdrop-blur-md"
                style={{
                  backgroundColor: 'rgba(255, 255, 255, 0.08)',
                  color: '#FFFFFF',
                }}
                id="hero-download-windows-btn"
              >
                <WindowsIcon className="w-4 h-4 text-white" />
                <span>Download for Windows</span>
              </button>
            </div>

            {/* Small platform footnote */}
            <p
              style={{
                fontSize: '13.5px',
                color: 'rgba(255, 255, 255, 0.65)',
                letterSpacing: '-0.01em',
                margin: '6px 0 0',
              }}
            >
              Free to download ·{' '}
              <button
                type="button"
                onClick={() => onOpenDownload('macos')}
                className="underline underline-offset-2 hover:text-white cursor-pointer"
              >
                macOS
              </button>
              ,{' '}
              <button
                type="button"
                onClick={() => onOpenDownload('windows')}
                className="underline underline-offset-2 hover:text-white cursor-pointer"
              >
                Windows
              </button>{' '}
              &amp;{' '}
              <button
                type="button"
                onClick={() => onOpenDownload('linux')}
                className="underline underline-offset-2 hover:text-white cursor-pointer"
              >
                Linux
              </button>
            </p>
          </div>

          {/* Social Proof: Avatars & Rating */}
          <div className="mt-9 flex items-center gap-3.5">
            <div className="flex shrink-0">
              {AVATARS.map((src, i) => (
                <img
                  key={src}
                  src={src}
                  alt=""
                  aria-hidden="true"
                  width="40"
                  height="40"
                  className="w-10 h-10 rounded-full object-cover relative"
                  style={{
                    border: '2px solid rgba(255,255,255,0.2)',
                    boxShadow: '0 0 0 1px rgba(0, 0, 0, 0.3)',
                    marginLeft: i === 0 ? 0 : -12,
                    zIndex: AVATARS.length - i,
                  }}
                  onError={(e) => {
                    // fallback graceful circle
                    e.currentTarget.style.display = 'none';
                  }}
                />
              ))}
            </div>
            <div className="flex flex-col text-left">
              <div
                aria-hidden="true"
                style={{
                  color: '#FFB800',
                  fontSize: '13px',
                  lineHeight: 1,
                  letterSpacing: '1px',
                }}
              >
                ★★★★★
              </div>
              <span
                style={{
                  fontSize: '14px',
                  fontWeight: 600,
                  color: '#FFFFFF',
                  letterSpacing: '-0.01em',
                  lineHeight: 1.2,
                  marginTop: '3px',
                }}
              >
                Used by 10,000+ great minds
              </span>
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Hero Screen Preview with Real Overlay */}
        <div className="w-full flex justify-center items-center">
          <div
            className="relative w-full max-w-[720px] rounded-[22px] overflow-hidden shadow-[0_24px_50px_-12px_rgba(20,16,10,0.25)] border border-[#27231D]/10"
            style={{
              aspectRatio: '760 / 616',
              backgroundColor: '#1E1B18',
            }}
          >
            {/* Background Video / Poster */}
            <video
              ref={videoRef}
              src="https://www.getjarvis.eu/hero-card.mp4"
              poster="/hero-card-poster.webp"
              autoPlay
              loop
              muted
              playsInline
              className="absolute inset-0 w-full h-full object-cover"
            />

            {/* Safari Chrome Bar at Top */}
            <div className="absolute top-0 left-0 right-0 h-9 bg-black/40 backdrop-blur-md flex items-center px-4 gap-2 z-10 border-b border-white/10">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-[#FF5F56]/90" />
                <div className="w-3 h-3 rounded-full bg-[#FFBD2E]/90" />
                <div className="w-3 h-3 rounded-full bg-[#27C93F]/90" />
              </div>
              <div className="mx-auto text-xs text-white/50 tracking-wide font-medium">
                {scene.name} · Wikipedia
              </div>
            </div>

            {/* Interactive Floating Jarvis Bar on Screen */}
            <div
              className="absolute z-20 transition-all duration-500 pointer-events-auto"
              style={{
                bottom: '24px',
                left: '20px',
                right: '20px',
              }}
            >
              <div
                className="p-4 rounded-2xl backdrop-blur-2xl border border-white/20 shadow-[0_20px_40px_rgba(0,0,0,0.5)] flex flex-col gap-2.5 transition-all"
                style={{
                  backgroundColor: 'rgba(18, 16, 24, 0.88)',
                  color: '#FFFFFF',
                }}
              >
                {/* Header Row of the Bar */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <img
                      src="/sidebar-logo.png"
                      alt="Jarvis"
                      className="h-4 w-auto brightness-200"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                      }}
                    />
                    <span className="text-xs font-semibold text-white/70 uppercase tracking-wider">
                      Screen Context Active
                    </span>
                  </div>
                  {/* Scene selector tabs */}
                  <div className="flex items-center gap-1 bg-white/10 p-0.5 rounded-lg text-[11px]">
                    {SCENES.map((s, idx) => (
                      <button
                        key={s.id}
                        type="button"
                        onClick={() => setActiveSceneIndex(idx)}
                        className={`px-2 py-0.5 rounded transition-all cursor-pointer ${
                          idx === activeSceneIndex
                            ? 'bg-white/20 text-white font-medium shadow-sm'
                            : 'text-white/50 hover:text-white'
                        }`}
                      >
                        {s.name}
                      </button>
                    ))}
                  </div>
                </div>

                {/* User Prompt */}
                <div className="flex items-center gap-2 text-sm font-medium text-white/95">
                  <span className="text-[#A277FF]">Q:</span>
                  <span>{scene.q}</span>
                </div>

                {/* Jarvis Live Answer */}
                <div className="text-[13px] leading-relaxed text-white/80 border-t border-white/10 pt-2 font-normal">
                  <span className="text-[#38D9A9] font-medium mr-1.5">Jarvis:</span>
                  <span>{displayedAnswer}</span>
                  {isTyping && <span className="inline-block w-1.5 h-3.5 bg-white/70 ml-1 animate-pulse" />}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Scroll invitation */}
        <div className="col-span-full flex justify-center -mt-4 pb-2">
          <a
            href="#cinematic-experience"
            onClick={(e) => {
              e.preventDefault();
              const el = document.getElementById('cinematic-experience');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="group inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#27231D]/5 hover:bg-[#27231D]/10 text-xs font-mono text-[#27231D]/70 transition-all cursor-pointer"
          >
            <span>Scroll for cinematic screen experience</span>
            <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" className="group-hover:translate-y-0.5 transition-transform">
              <path d="M4 6l4 4 4-4" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
}
