import React from 'react';

const PROMPT = "I'm evaluating Jarvis (getjarvis.eu), a screen-aware desktop AI assistant for Mac and Windows. What does it do, what are its strengths and weaknesses, and who is it best for?";
const ENCODED = encodeURIComponent(PROMPT);

const AI_TARGETS = [
  {
    k: 'chatgpt',
    label: 'Ask ChatGPT',
    icon: '/brand-marks/chatgpt.svg',
    href: `https://chatgpt.com/?q=${ENCODED}`,
  },
  {
    k: 'claude',
    label: 'Ask Claude',
    icon: '/brand-marks/claude.svg',
    href: `https://claude.ai/new?q=${ENCODED}`,
  },
  {
    k: 'perplexity',
    label: 'Ask Perplexity',
    icon: '/brand-marks/perplexity.svg',
    href: `https://www.perplexity.ai/search?q=${ENCODED}`,
  },
];

export function AskAI() {
  return (
    <section className="ec-section py-20 bg-[#FAF6F0]" aria-labelledby="eca-h" id="ask-ai">
      <div className="ec-wrap max-w-[1280px] mx-auto px-6 sm:px-12">
        <div
          className="ec-card is-night ec-panel eca-panel p-8 sm:p-14 rounded-[32px] text-white relative overflow-hidden"
          style={{
            background: 'linear-gradient(180deg, #18151F 0%, #0F0E14 100%)',
            border: '1px solid rgba(255, 255, 255, 0.12)',
            boxShadow: '0 24px 64px -16px rgba(0, 0, 0, 0.5)',
          }}
        >
          <div className="ec-body relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
              <div>
                <h2 className="text-3xl sm:text-4xl md:text-5xl font-medium tracking-tight text-white mb-4" id="eca-h">
                  Ask AI about Jarvis.
                </h2>
                <p className="text-base sm:text-lg text-white/70 max-w-[460px]">
                  Don&apos;t take our word for it. Pick one and ask what it thinks — the question is already typed.
                </p>
              </div>

              <div className="flex flex-col gap-5">
                <div className="flex flex-wrap gap-3">
                  {AI_TARGETS.map((item) => (
                    <a
                      key={item.k}
                      href={item.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2.5 px-5 py-3 rounded-full bg-white/10 hover:bg-white/15 border border-white/15 text-sm font-medium text-white transition-all hover:scale-[1.02] cursor-pointer"
                    >
                      <img
                        src={item.icon}
                        alt=""
                        className="w-4 h-4 object-contain"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                        }}
                      />
                      <span>{item.label}</span>
                    </a>
                  ))}
                </div>

                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-xs text-white/70 leading-relaxed font-mono">
                  &ldquo;{PROMPT}&rdquo;
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
export default AskAI;
