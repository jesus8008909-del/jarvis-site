import React, { useState } from 'react';
import { AppleIcon, WindowsIcon, LinuxIcon, JarvisLogo } from './JarvisLogo';
import { X, Download, CheckCircle, ShieldCheck, Terminal, ArrowRight } from 'lucide-react';
import { OS } from '../types';

interface DownloadModalProps {
  initialOS: OS;
  isOpen: boolean;
  onClose: () => void;
}

export function DownloadModal({ initialOS, isOpen, onClose }: DownloadModalProps) {
  const [selectedOS, setSelectedOS] = useState<OS>(initialOS);
  const [downloadProgress, setDownloadProgress] = useState<number>(0);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadComplete, setDownloadComplete] = useState(false);

  // Sync initial OS when modal opens
  React.useEffect(() => {
    setSelectedOS(initialOS);
    setDownloadProgress(0);
    setIsDownloading(false);
    setDownloadComplete(false);
  }, [initialOS, isOpen]);

  if (!isOpen) return null;

  const triggerDownload = () => {
    setIsDownloading(true);
    setDownloadProgress(0);
    setDownloadComplete(false);

    let downloadUrl = 'https://api.getjarvis.eu/download/mac';
    if (selectedOS === 'windows') {
      downloadUrl = 'https://api.getjarvis.eu/download/windows';
    } else if (selectedOS === 'linux') {
      downloadUrl = 'https://api.getjarvis.eu/download/linux';
    }

    try {
      window.open(downloadUrl, '_blank');
    } catch {}

    const interval = setInterval(() => {
      setDownloadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsDownloading(false);
          setDownloadComplete(true);
          return 100;
        }
        return prev + 25;
      });
    }, 200);
  };

  const getFileName = () => {
    switch (selectedOS) {
      case 'macos':
        return 'Jarvis-2.4.1-universal.dmg';
      case 'windows':
        return 'Jarvis-Setup-2.4.1-x64.exe';
      case 'linux':
        return 'jarvis_2.4.1_amd64.deb';
    }
  };

  const getRequirements = () => {
    switch (selectedOS) {
      case 'macos':
        return 'macOS 12.0 Monterey or later (Apple Silicon M1/M2/M3/M4 & Intel)';
      case 'windows':
        return 'Windows 10 / Windows 11 (64-bit or ARM64)';
      case 'linux':
        return 'Ubuntu 20.04+, Debian 11+, Fedora 36+, or Arch Linux';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        className="bg-white rounded-2xl max-w-lg w-full border border-neutral-200 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-neutral-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="text-neutral-900">
              <JarvisLogo className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-neutral-900 text-base">Download Jarvis</h3>
              <p className="text-xs text-neutral-500">v2.4.1 · Latest Release</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-800 hover:bg-neutral-100 transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* OS Switcher Pills */}
          <div className="grid grid-cols-3 gap-2 bg-neutral-100 p-1 rounded-xl mb-6">
            <button
              type="button"
              onClick={() => {
                setSelectedOS('macos');
                setDownloadComplete(false);
              }}
              className={`flex items-center justify-center gap-2 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                selectedOS === 'macos'
                  ? 'bg-white text-neutral-900 shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <AppleIcon className="w-3.5 h-3.5" />
              <span>macOS</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setSelectedOS('windows');
                setDownloadComplete(false);
              }}
              className={`flex items-center justify-center gap-2 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                selectedOS === 'windows'
                  ? 'bg-white text-neutral-900 shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <WindowsIcon className="w-3.5 h-3.5" />
              <span>Windows</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setSelectedOS('linux');
                setDownloadComplete(false);
              }}
              className={`flex items-center justify-center gap-2 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                selectedOS === 'linux'
                  ? 'bg-white text-neutral-900 shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <LinuxIcon className="w-3.5 h-3.5" />
              <span>Linux</span>
            </button>
          </div>

          {/* Package details */}
          <div className="bg-neutral-50 rounded-xl p-4 border border-neutral-200/80 mb-6">
            <div className="flex items-center justify-between text-xs text-neutral-700 font-medium mb-1">
              <span>Package:</span>
              <span className="font-mono text-neutral-900">{getFileName()}</span>
            </div>
            <div className="flex items-center justify-between text-xs text-neutral-500 mb-2">
              <span>Size:</span>
              <span>84.2 MB</span>
            </div>
            <div className="text-[11.5px] text-neutral-500 border-t border-neutral-200/60 pt-2 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>{getRequirements()}</span>
            </div>
          </div>

          {/* Download Action Area */}
          {downloadComplete ? (
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-center">
              <CheckCircle className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
              <p className="font-bold text-emerald-950 text-sm">Download Started!</p>
              <p className="text-xs text-emerald-700 mt-1">
                Open <span className="font-mono">{getFileName()}</span> once complete. Press <kbd className="px-1 py-0.5 bg-white rounded border border-emerald-300 font-mono text-[10px]">⌘ Shift J</kbd> to launch Jarvis anywhere.
              </p>
            </div>
          ) : isDownloading ? (
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-medium text-neutral-700">
                <span>Downloading {getFileName()}...</span>
                <span>{downloadProgress}%</span>
              </div>
              <div className="w-full bg-neutral-100 rounded-full h-2.5 overflow-hidden">
                <div 
                  className="bg-neutral-900 h-2.5 rounded-full transition-all duration-300"
                  style={{ width: `${downloadProgress}%` }}
                />
              </div>
            </div>
          ) : (
            <button
              type="button"
              onClick={triggerDownload}
              className="w-full flex items-center justify-center gap-2.5 py-3.5 px-5 rounded-xl bg-neutral-900 text-white font-medium text-sm hover:bg-neutral-800 active:scale-[0.99] transition-all cursor-pointer shadow-sm"
              id="confirm-download-btn"
            >
              <Download className="w-4 h-4" />
              <span>Download {selectedOS === 'macos' ? 'for macOS (.dmg)' : selectedOS === 'windows' ? 'for Windows (.exe)' : 'for Linux (.deb)'}</span>
            </button>
          )}

          {/* Quick Terminal command for developers */}
          {selectedOS === 'macos' && (
            <div className="mt-4 pt-4 border-t border-neutral-100">
              <p className="text-[11px] text-neutral-500 mb-1 flex items-center gap-1 font-mono">
                <Terminal className="w-3 h-3" />
                Or install via Homebrew:
              </p>
              <div className="bg-neutral-900 text-neutral-200 font-mono text-xs p-2.5 rounded-lg flex items-center justify-between select-all">
                <span>brew install --cask jarvis</span>
              </div>
            </div>
          )}
          {selectedOS === 'windows' && (
            <div className="mt-4 pt-4 border-t border-neutral-100">
              <p className="text-[11px] text-neutral-500 mb-1 flex items-center gap-1 font-mono">
                <Terminal className="w-3 h-3" />
                Or install via Winget:
              </p>
              <div className="bg-neutral-900 text-neutral-200 font-mono text-xs p-2.5 rounded-lg flex items-center justify-between select-all">
                <span>winget install Jarvis.Jarvis</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
