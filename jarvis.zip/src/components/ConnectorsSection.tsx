import React, { useState } from 'react';
import { CONNECTORS } from '../data/mockData';
import { Code2, MessageSquare, Layers, Globe, Zap, Monitor, ArrowRight, CheckCircle2, ShieldCheck, Sparkles } from 'lucide-react';
import { Connector } from '../types';

export function ConnectorsSection() {
  const [activeConnector, setActiveConnector] = useState<Connector>(CONNECTORS[0]);
  const [connectedApps, setConnectedApps] = useState<Record<string, boolean>>({
    vscode: true,
    slack: true,
    figma: false,
    notion: true,
    linear: false,
    chrome: true,
  });

  const toggleConnect = (id: string) => {
    setConnectedApps(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const getIcon = (name: string) => {
    switch (name) {
      case 'Code2': return Code2;
      case 'MessageSquare': return MessageSquare;
      case 'Layers': return Layers;
      case 'Globe': return Globe;
      case 'Zap': return Zap;
      default: return Monitor;
    }
  };

  return (
    <section id="connectors" className="py-16 sm:py-24 px-4 sm:px-6 max-w-6xl mx-auto border-t border-neutral-200/80">
      <div className="text-center mb-12 sm:mb-16">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider text-neutral-600 bg-neutral-200/80 mb-3">
          <span>Connectors & Ecosystem</span>
        </div>
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-neutral-900 tracking-tight">
          Connect it to your apps so it learns your world
        </h2>
        <p className="mt-3 text-lg text-neutral-600 max-w-2xl mx-auto">
          Jarvis links locally to your everyday tools. No cloud uploads of your private workspaces; everything indexes privately on your machine.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* App List on Left */}
        <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-2.5">
          {CONNECTORS.map((connector) => {
            const Icon = getIcon(connector.iconName);
            const isSelected = activeConnector.id === connector.id;
            const isConnected = connectedApps[connector.id];

            return (
              <div
                key={connector.id}
                onClick={() => setActiveConnector(connector)}
                className={`p-3.5 sm:p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                  isSelected
                    ? 'bg-white border-neutral-900 shadow-md ring-1 ring-neutral-900/10'
                    : 'bg-white/60 hover:bg-white border-neutral-200/80 hover:border-neutral-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div 
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-white shrink-0 shadow-xs"
                    style={{ backgroundColor: connector.color }}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-neutral-900 text-sm">{connector.name}</h3>
                    <p className="text-xs text-neutral-500 line-clamp-1">{connector.description}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleConnect(connector.id);
                    }}
                    className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                      isConnected
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200 border border-neutral-200'
                    }`}
                  >
                    {isConnected ? 'Active' : 'Enable'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Live Connector Preview on Right */}
        <div className="lg:col-span-7 bg-white border border-neutral-200/90 rounded-2xl p-6 sm:p-8 shadow-sm">
          <div className="flex items-center justify-between border-b border-neutral-100 pb-5">
            <div className="flex items-center gap-3">
              <div 
                className="w-12 h-12 rounded-xl flex items-center justify-center text-white shadow-xs"
                style={{ backgroundColor: activeConnector.color }}
              >
                {React.createElement(getIcon(activeConnector.iconName), { className: "w-6 h-6" })}
              </div>
              <div>
                <h4 className="text-lg font-bold text-neutral-900">{activeConnector.name}</h4>
                <p className="text-xs text-neutral-500">Local Connector Status: Ready</p>
              </div>
            </div>

            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
              <ShieldCheck className="w-3.5 h-3.5" />
              100% On-Device
            </span>
          </div>

          <div className="mt-6 space-y-4">
            <div>
              <h5 className="text-xs font-semibold uppercase tracking-wider text-neutral-500 mb-1">Capabilities</h5>
              <p className="text-neutral-700 text-sm leading-relaxed">{activeConnector.description}</p>
            </div>

            <div className="bg-neutral-50 rounded-xl p-4 border border-neutral-200/70">
              <div className="text-xs font-medium text-neutral-500 mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Example Query from your active screen</span>
              </div>
              <div className="p-3 bg-white rounded-lg border border-neutral-200/80 text-sm font-semibold text-neutral-800 mb-3">
                "{activeConnector.sampleQuery}"
              </div>
              <div className="text-xs font-medium text-neutral-500 mb-1">Jarvis Direct Answer:</div>
              <div className="text-xs sm:text-sm text-neutral-700 bg-neutral-100/80 p-3 rounded-lg border border-neutral-200/50">
                {activeConnector.sampleAnswer}
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between text-xs text-neutral-500">
              <span>Latency: &lt;140ms</span>
              <span>Zero cloud data leakage</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
