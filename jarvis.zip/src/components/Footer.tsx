import React from 'react';

const PRODUCT_LINKS = [
  { label: 'Features', href: '#reasons' },
  { label: 'Connectors', href: '#connectors' },
  { label: 'Integrations', href: '#integrations' },
  { label: 'Demo Videos', href: '#hero' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'Desktop AI assistant', href: '#top' },
  { label: 'Screen-aware AI', href: '#top' },
  { label: 'AI assistant for Mac', href: '#download' },
  { label: 'AI assistant for Windows', href: '#download' },
  { label: 'AI assistant for Linux', href: '#download' },
  { label: 'Jarvis for PC', href: '#download' },
  { label: 'Download for Mac', href: '#download' },
  { label: 'Download for Windows', href: '#download' },
  { label: 'Download for Linux', href: '#download' },
];

const USE_CASES_LINKS = [
  { label: 'Use cases', href: '#use-cases' },
  { label: 'For indie founders', href: '#use-cases' },
  { label: 'For designers', href: '#use-cases' },
  { label: 'For students', href: '#use-cases' },
  { label: 'For developers', href: '#use-cases' },
  { label: 'For product managers', href: '#use-cases' },
  { label: 'For sales', href: '#use-cases' },
  { label: 'For customer success', href: '#use-cases' },
  { label: 'For marketers', href: '#use-cases' },
  { label: 'Introducing Jarvis v1', href: '#blog' },
];

const COMPARE_LINKS = [
  { label: 'vs ChatGPT', href: '#compare' },
  { label: 'vs Claude', href: '#compare' },
  { label: 'vs Cursor', href: '#compare' },
  { label: 'vs Cluely', href: '#compare' },
  { label: 'vs Perplexity', href: '#compare' },
  { label: 'vs Microsoft Copilot', href: '#compare' },
  { label: 'vs Raycast AI', href: '#compare' },
  { label: 'vs Apple Intelligence', href: '#compare' },
  { label: 'vs Rewind / Limitless', href: '#compare' },
  { label: 'vs Highlight AI', href: '#compare' },
  { label: 'vs Granola', href: '#compare' },
  { label: 'vs Otter.ai', href: '#compare' },
  { label: 'vs Superwhisper', href: '#compare' },
  { label: 'vs Wispr Flow', href: '#compare' },
  { label: 'vs Sider AI', href: '#compare' },
  { label: 'Best desktop AI assistants 2026', href: '#compare' },
];

const RESOURCES_LINKS = [
  { label: 'Blog', href: '#blog' },
  { label: 'Changelog', href: '#changelog' },
  { label: 'Documentation', href: '#docs' },
  { label: 'Keyboard Shortcuts', href: '#shortcuts' },
  { label: 'Community', href: '#community' },
  { label: 'Roadmap', href: '#roadmap' },
];

const SUPPORT_LINKS = [
  { label: 'Contact', href: 'mailto:support@getjarvis.eu', isExternal: true },
  { label: 'About', href: '#about' },
  { label: 'Is Jarvis AI legit?', href: '#faq' },
  { label: 'Reviews', href: '#reviews' },
  { label: 'Security', href: '#security' },
  { label: 'Privacy Policy', href: '#privacy' },
  { label: 'Terms of Service', href: '#terms' },
];

export function Footer() {
  return (
    <footer
      className="relative bg-[#FAF6F0] border-t border-[#27231D]/10 overflow-hidden text-[#27231D]"
      id="footer"
    >
      {/* Giant faint wordmark at bottom */}
      <img
        src="/site-assets/brand/wordmark-v1-gradient.png"
        alt=""
        aria-hidden="true"
        width="1916"
        height="821"
        loading="lazy"
        decoding="async"
        className="footer-wordmark-bg absolute left-0 bottom-0 z-0 w-full h-auto pointer-events-none select-none opacity-40"
        style={{
          WebkitMaskImage: 'linear-gradient(to bottom, transparent 0%, #000 40%)',
          maskImage: 'linear-gradient(to bottom, transparent 0%, #000 40%)',
        }}
      />

      <div className="relative z-10 max-w-[1360px] mx-auto px-6 sm:px-12 pt-20 pb-12">
        {/* Main Grid: Logo/Badges + 5 Nav Columns */}
        <div className="grid grid-cols-1 md:grid-cols-[1.4fr_repeat(4,1fr)] lg:grid-cols-[1.5fr_1fr_1fr_1.6fr_1fr_1fr] gap-10 lg:gap-12 items-start">
          {/* Brand Info & Badges */}
          <div className="flex flex-col items-start">
            <a href="#top" className="inline-block mb-3 select-none">
              <img
                src="/sidebar-logo-ink.png"
                alt="Jarvis"
                width="133"
                height="36"
                className="h-9 w-auto"
                onError={(e) => {
                  const target = e.currentTarget;
                  target.style.display = 'none';
                  if (target.parentElement) {
                    target.parentElement.innerHTML = '<span style="font-weight:700;font-size:24px;color:#27231D;">Jarvis</span>';
                  }
                }}
              />
            </a>
            <p className="text-sm text-[#27231D]/70 max-w-[240px] leading-relaxed mb-6">
              Your AI, right where you work.
            </p>

            {/* Product Hunt Widget Badge */}
            <a
              href="https://www.producthunt.com/products/jarvis-8?utm_source=badge-featured&utm_medium=badge&utm_campaign=badge-jarvis"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Find Jarvis on Product Hunt"
              className="inline-block mb-3 hover:opacity-90 transition-opacity"
            >
              <img
                src="https://api.producthunt.com/widgets/embed-image/v1/featured.svg?post_id=1168746&theme=light"
                alt="Jarvis - Don't leave the moment. Ask from here. | Product Hunt"
                width="250"
                height="54"
                className="w-full max-w-[210px] h-auto"
                loading="lazy"
              />
            </a>

            {/* LaunchBuff Badge */}
            <a
              href="https://launchbuff.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Featured on LaunchBuff"
              className="inline-block hover:opacity-90 transition-opacity"
            >
              <img
                src="https://launchbuff.com/badge-featured-light.svg"
                alt="Featured on LaunchBuff"
                width="256"
                height="80"
                className="w-full max-w-[190px] h-auto"
                loading="lazy"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
            </a>
          </div>

          {/* Product Column */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#27231D] mb-4">
              Product
            </h4>
            <ul className="space-y-2.5 text-sm text-[#27231D]/75">
              {PRODUCT_LINKS.map((link, i) => (
                <li key={`${link.label}-${i}`}>
                  <a href={link.href} className="hover:text-[#27231D] transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Use Cases Column */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#27231D] mb-4">
              Use cases
            </h4>
            <ul className="space-y-2.5 text-sm text-[#27231D]/75">
              {USE_CASES_LINKS.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="hover:text-[#27231D] transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Compare Column (2-column inside to fit compact) */}
          <div className="footer-compare-col">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#27231D] mb-4">
              Compare
            </h4>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2.5 text-sm text-[#27231D]/75">
              {COMPARE_LINKS.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="hover:text-[#27231D] transition-colors whitespace-nowrap">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources Column */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#27231D] mb-4">
              Resources
            </h4>
            <ul className="space-y-2.5 text-sm text-[#27231D]/75">
              {RESOURCES_LINKS.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="hover:text-[#27231D] transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support Column */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#27231D] mb-4">
              Support
            </h4>
            <ul className="space-y-2.5 text-sm text-[#27231D]/75">
              {SUPPORT_LINKS.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    target={link.isExternal ? '_blank' : undefined}
                    rel={link.isExternal ? 'noopener noreferrer' : undefined}
                    className="hover:text-[#27231D] transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Legal & Copyright Row */}
        <div
          className="mt-16 pt-6 border-t border-[#27231D]/10 flex flex-wrap items-center justify-between gap-4 text-xs text-[#27231D]/60"
          style={{ marginBottom: 'clamp(100px, 20vw, 240px)' }}
        >
          <span>© 2026 Jarvis. All rights reserved.</span>
          <span>
            Jarvis is a product of LOGICLUB SMART SRL · Strada Lector nr. 5, Sibiu 550245, Romania
          </span>
        </div>
      </div>
    </footer>
  );
}
