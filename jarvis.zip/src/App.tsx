import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { CinematicScroller } from './components/CinematicScroller';
import { BentoPair } from './components/BentoPair';
import { ScrollReveal } from './components/ScrollReveal';
import { UseCaseRail } from './components/UseCaseRail';
import { AskAnythingSection } from './components/AskAnythingSection';
import { JarvisVs } from './components/JarvisVs';
import { AppIntegrations } from './components/AppIntegrations';
import { Reviews } from './components/Reviews';
import { AskAI } from './components/AskAI';
import { FAQ } from './components/FAQ';
import { Footer } from './components/Footer';
import { DownloadModal } from './components/DownloadModal';
import { PricingModal } from './components/PricingModal';
import { JarvisOverlaySimulator } from './components/JarvisOverlaySimulator';
import { OS } from './types';

export default function App() {
  const [downloadModalOpen, setDownloadModalOpen] = useState(false);
  const [selectedOS, setSelectedOS] = useState<OS>('macos');
  const [pricingModalOpen, setPricingModalOpen] = useState(false);
  const [simulatorOpen, setSimulatorOpen] = useState(false);
  const [simulatorQuery, setSimulatorQuery] = useState('');

  const handleOpenDownload = (os?: OS) => {
    if (os) setSelectedOS(os);
    setDownloadModalOpen(true);
  };

  const handleOpenPricing = () => {
    setPricingModalOpen(true);
  };

  const handleLaunchSimulator = (query?: string) => {
    setSimulatorQuery(query || '');
    setSimulatorOpen(true);
  };

  const handleNavigateSection = (sectionId: string) => {
    if (sectionId === 'top') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative min-h-screen text-white selection:bg-red-600 selection:text-white">
      {/* Background Video: Muted and Looped */}
      <div className="fixed inset-0 pointer-events-none -z-20 overflow-hidden bg-[#0A090D]">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover object-center scale-105 opacity-65"
          poster="/robot-bg.jpg"
        >
          <source src="/robot-bg.mp4" type="video/mp4" />
        </video>
        {/* Cinematic Vignette & Deep Crimson Atmosphere */}
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(ellipse at 65% 45%, rgba(220, 20, 40, 0.12) 0%, rgba(10, 9, 13, 0.72) 65%, rgba(10, 9, 13, 0.94) 100%), linear-gradient(to bottom, rgba(10, 9, 13, 0.45) 0%, rgba(10, 9, 13, 0.78) 100%)',
          }}
        />
      </div>

      {/* Liquid Glass Navbar */}
      <Navbar
        onOpenDownload={handleOpenDownload}
        onOpenPricing={handleOpenPricing}
        onNavigateSection={handleNavigateSection}
      />

      <main>
        {/* 1. Interactive Hero Section */}
        <Hero
          onOpenDownload={handleOpenDownload}
          onLaunchSimulator={() => handleLaunchSimulator()}
        />

        {/* Cinematic Scroll Experience: Visuals as Full-Bleed Backdrops */}
        <CinematicScroller onOpenDownload={handleOpenDownload} />

        {/* 2. Four Reasons Bento Grid */}
        <ScrollReveal yOffset={32} duration={0.8}>
          <BentoPair onOpenDownload={handleOpenDownload} />
        </ScrollReveal>

        {/* 3. Skill & Use Case Carousel Rail */}
        <ScrollReveal yOffset={32} duration={0.8} delay={0.05}>
          <UseCaseRail />
        </ScrollReveal>

        {/* 4. Ask About Anything You See Demo */}
        <ScrollReveal yOffset={32} duration={0.8}>
          <AskAnythingSection onOpenDownload={handleOpenDownload} />
        </ScrollReveal>

        {/* 5. Jarvis vs Chatbots Comparison */}
        <ScrollReveal yOffset={32} duration={0.8}>
          <JarvisVs />
        </ScrollReveal>

        {/* 6. 30+ App Integrations Wall */}
        <ScrollReveal yOffset={32} duration={0.8}>
          <AppIntegrations onOpenConnectors={handleOpenPricing} />
        </ScrollReveal>

        {/* 7. What Our Users Say (Reviews) */}
        <ScrollReveal yOffset={32} duration={0.8}>
          <Reviews />
        </ScrollReveal>

        {/* 8. Ask AI (ChatGPT / Claude / Perplexity) */}
        <ScrollReveal yOffset={32} duration={0.8}>
          <AskAI />
        </ScrollReveal>

        {/* 9. Authentic FAQ Section (23 questions) */}
        <ScrollReveal yOffset={32} duration={0.8}>
          <FAQ />
        </ScrollReveal>
      </main>

      {/* 10. Footer with Multi-column Links, LOGICLUB SMART SRL & Wordmark */}
      <ScrollReveal yOffset={24} duration={0.7}>
        <Footer />
      </ScrollReveal>

      {/* Download Modal Dialog */}
      <DownloadModal
        initialOS={selectedOS}
        isOpen={downloadModalOpen}
        onClose={() => setDownloadModalOpen(false)}
      />

      {/* Pricing Modal Dialog */}
      <PricingModal
        isOpen={pricingModalOpen}
        onClose={() => setPricingModalOpen(false)}
        onSelectPlan={(_plan) => {
          setPricingModalOpen(false);
          handleOpenDownload();
        }}
      />

      {/* Live Floating Jarvis HUD Overlay Simulator */}
      <JarvisOverlaySimulator
        isOpen={simulatorOpen}
        initialQuery={simulatorQuery}
        onClose={() => setSimulatorOpen(false)}
      />
    </div>
  );
}
